import xbmcaddon

addon_id = xbmcaddon.Addon().getAddonInfo('id')

'''#####-----Build File-----#####'''
buildfile = 'http://funstersplace.net/text/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://funstersplace.net/text/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = [addon_id, 'packages', 'backups', 'plugin.video.whatever']
