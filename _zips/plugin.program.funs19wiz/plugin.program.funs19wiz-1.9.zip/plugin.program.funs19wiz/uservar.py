import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://funstersplace.net/text/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://funstersplace.net/text/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
