import logging,re,time,os
from resources.modules import cache
global local
from resources.modules import log
from resources.menus import CLIENT_ID,CLIENT_SECRET
local=False
try:
    import urllib3

    urllib3.disable_warnings()
except:
  pass
try:
   import xbmcgui,xbmc
   import xbmcaddon
   Addon = xbmcaddon.Addon()
   local=False
except:
  import Addon
  local=True
  rd_domains=[u'4shared.com', u'openload.co', u'rapidgator.net', u'sky.fm', u'1fichier.com', u'docs.google.com', u'depositfiles.com', u'hitfile.net', u'rapidvideo.com', u'filerio.com', u'solidfiles.com', u'mega.co.nz', u'scribd.com', u'flashx.tv', u'canalplus.fr', u'dailymotion.com', u'salefiles.com', u'youtube.com', u'faststore.org', u'turbobit.net', u'big4shared.com', u'filefactory.com', u'youporn.com', u'oboom.com', u'vimeo.com', u'redtube.com', u'zippyshare.com', u'file.al', u'clicknupload.me', u'soundcloud.com', u'gigapeta.com', u'datafilehost.com', u'datei.to', u'rutube.ru', u'load.to', u'streamango.com', u'sendspace.com', u'vidoza.net', u'tusfiles.net', u'unibytes.com', u'ulozto.net', u'hulkshare.com', u'dl.free.fr', u'streamcherry.com', u'vidlox.tv', u'mediafire.com', u'vk.com', u'uploaded.net', u'userscloud.com']
  pass
hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net',
                   'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net','uploadgig.com']
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
lang=xbmc.getLanguage(0)
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
else:
    import xbmcvfs
    xbmc_tranlate_path=xbmcvfs.translatePath
addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))
if Addon.getSetting("theme")=='0':
    art_folder='artwork'
elif Addon.getSetting("theme")=='1':
    art_folder='artwork_keshav'
elif Addon.getSetting("theme")=='2':
    art_folder='artwork_shinobi'
elif Addon.getSetting("theme")=='3':
    art_folder='artwork_sonic'
elif Addon.getSetting("theme")=='4':
    art_folder='artwork_bob'
BASE_LOGO=os.path.join(addonPath, 'resources', art_folder+'/')
addon = xbmcaddon.Addon()
addon_name=addon.getAddonInfo('name')
addon_id=addon.getAddonInfo('id')
tmdb_key=Addon.getSetting("tmdb_api")
try:
    import xbmc
    KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
    if KODI_VERSION>18:
        from urllib.parse import urlparse
    else:
        from urllib import urlparse
    if KODI_VERSION>=17:
     
      domain_s='https://'
    elif KODI_VERSION<17:
      domain_s='http://'
   
except:
    domain_s='https://'
all_colors=['aliceblue', 'anitquewhite', 'aqua', 'aquamarine', 'azure', 'beige', 'bisque', 'black', 'blanchedalmond', 'blue', 'blueviolet', 'brown', 'burlywood', 'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornflowerblue', 'cornsilk', 'crimson', 'cyan', 'darkblue', 'darkcyan', 'darkgoldenrod', 'darkgray', 'darkgreen', 'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred', 'darksalmon', 'darkseagreen', 'darkslateblue', 'darkslategray', 'darkturquoise', 'darkviolet', 'deeppink', 'deepskyblue', 'dimgray', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro', 'ghostwhite', 'gold', 'goldenrod', 'gray', 'green', 'greenyellow', 'honeydew', 'hotpink', 'indianred ', 'indigo  ', 'ivory', 'khaki', 'kodi', 'lavender', 'lavenderblush', 'lawngreen', 'lemonchiffon', 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow', 'lightgray', 'lightgreen', 'lightpink', 'lightsalmon', 'lightseagreen', 'lightskyblue', 'lightslategray', 'lightsteelblue', 'lightyellow', 'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'mediumaquamarine', 'mediumblue', 'mediumorchid', 'mediumpurple', 'mediumseagreen', 'mediumslateblue', 'mediumspringgreen', 'mediumturquoise', 'mediumvioletred', 'midnightblue', 'mintcream', 'mistyrose', 'moccasin', 'navajowhite', 'navy', 'none', 'oldlace', 'olive', 'olivedrab', 'orange', 'orangered', 'orchid', 'palegoldenrod', 'palegreen', 'paleturquoise', 'palevioletred', 'papayawhip', 'peachpuff', 'peru', 'pink', 'plum', 'powderblue', 'purple', 'red', 'rosybrown', 'royalblue', 'saddlebrown', 'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna', 'silver', 'skyblue', 'slateblue', 'slategray', 'snow', 'springgreen', 'steelblue', 'tan', 'teal', 'thistle', 'tomato', 'turquoise', 'violet', 'white', 'whitesmoke', 'yellow', 'yellowgreen']
from resources.modules.public import get_html_g
from  resources.modules.client import get_html
html_g_tv,html_g_movie=cache.get(get_html_g,72, table='posters')
rd_sources=Addon.getSetting("rdsource")
allow_debrid = rd_sources == "true" 
if allow_debrid:
    rd_domains=cache.get(get_rd_servers, 720, table='RD_Account')
else:
    rd_domains=[]
if local:
    rd_domains=[u'4shared.com', u'openload.co', u'rapidgator.net', u'sky.fm', u'1fichier.com', u'docs.google.com', u'depositfiles.com', u'hitfile.net', u'rapidvideo.com', u'filerio.com', u'solidfiles.com', u'mega.co.nz', u'scribd.com', u'flashx.tv', u'canalplus.fr', u'dailymotion.com', u'salefiles.com', u'youtube.com', u'faststore.org', u'turbobit.net', u'big4shared.com', u'filefactory.com', u'youporn.com', u'oboom.com', u'vimeo.com', u'redtube.com', u'zippyshare.com', u'file.al', u'clicknupload.me', u'soundcloud.com', u'gigapeta.com', u'datafilehost.com', u'datei.to', u'rutube.ru', u'load.to', u'streamango.com', u'sendspace.com', u'vidoza.net', u'tusfiles.net', u'unibytes.com', u'ulozto.net', u'hulkshare.com', u'dl.free.fr', u'streamcherry.com', u'vidlox.tv', u'mediafire.com', u'vk.com', u'uploaded.net', u'userscloud.com']
def get_vstram_title(original_name,html2):
    name1=original_name
   
    regex='"og:title" content="(.+?)"'
    match4=re.compile(regex).findall(html2)
  
    
    if len( match4)==0:
        
        regex='<Title>(.+?)</Title>'
        
        match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
         regex='name="fname" value="(.+?)"'
         match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
         regex='<title>(.+?)</title>'
         match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
         regex="title: '(.+?)',"
         match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
         regex='><span title="(.+?)"'
         match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
         regex='description" content="(.+?)"'
         match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)==0:
        regex='"title","(.+?)"'
        match4=re.compile(regex,re.DOTALL).findall(html2)
    if len(match4)>0:
        name1=match4[0]
    log.warning(match4)
    log.warning(name1)
    return name1.replace("."," ").replace('Watch','').replace('watch','').replace(' mp4','').replace('watch','').replace(' MP4','').replace(' mkv','').replace(' MKV','').replace("_",".")
    
def get_imdb(tv_movie,id):
    tmdbKey='653bb8af90162bd98fc7ee32bcbbfb3d'
    if tv_movie=='tv':
      
       url2=f'https://api.themoviedb.org/3/tv/%s?api_key={tmdb_key}&append_to_response=external_ids'%(id)
    else:
       
       url2=f'https://api.themoviedb.org/3/movie/%s?api_key={tmdb_key}&append_to_response=external_ids'%(id)
    try:
        
        imdb_id=get_html(url2,timeout=10).json()['external_ids']['imdb_id']
    except:
        imdb_id=" "
    return imdb_id
def get_rd_servers():
    
        rd_domains=[]
        try:
            import real_debrid
            rd = real_debrid.RealDebrid()
            rd_domains=(rd.getRelevantHosters())
if len(rd_domains)==0:
                    Addon.setSetting('rd.client_id','')
                    rd.auth()
                    rd = real_debrid.RealDebrid()
                    rd_domains=(rd.getRelevantHosters())
            rd_domains.append('nitroflare.com')
            rd_domains.append('rapidgator.net')
            rd_domains.append('uploadgig.com')
        except Exception as e:
            rd_domains=[u'4shared.com', u'openload.co', u'rapidgator.net', u'sky.fm', u'1fichier.com', u'docs.google.com', u'depositfiles.com', u'hitfile.net', u'rapidvideo.com', u'filerio.com', u'solidfiles.com', u'mega.co.nz', u'scribd.com', u'flashx.tv', u'canalplus.fr', u'dailymotion.com', u'salefiles.com', u'youtube.com', u'faststore.org', u'turbobit.net', u'big4shared.com', u'filefactory.com', u'youporn.com', u'oboom.com', u'vimeo.com', u'redtube.com', u'zippyshare.com', u'file.al', u'clicknupload.me', u'soundcloud.com', u'gigapeta.com', u'datafilehost.com', u'datei.to', u'rutube.ru', u'load.to', u'streamango.com', u'sendspace.com', u'vidoza.net', u'tusfiles.net', u'unibytes.com', u'ulozto.net', u'hulkshare.com', u'dl.free.fr', u'streamcherry.com', u'vidlox.tv', u'mediafire.com', u'vk.com', u'uploaded.net', u'userscloud.com']
            pass
        return rd_domains


base_header={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',

            'Pragma': 'no-cache',
            
           
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            }
class cleantitle():
   @classmethod
   def get(self,name):
    return name.replace('%20',' ').replace('%3a',':').replace('%27',"'")
class client():

  def init(self, url):
        self.url = url 
  @classmethod
  def request(self,url,cookie=None):
     headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
           
            'Pragma': 'no-cache',
            
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
     return get_html(url,headers=headers,cookies=cookie).content
BASE_URL = 'http://api.trakt.tv'
SETTING_TRAKT_EXPIRES_AT = "trakt_expires_at"
SETTING_TRAKT_ACCESS_TOKEN = "trakt_access_token"
SETTING_TRAKT_REFRESH_TOKEN = "trakt_refresh_token"

def reset_trakt():
    ret =xbmcgui.Dialog().yesno(("Authenticate Trakt"), ("Clear Trakt Auth.?"))
    if ret:
      Addon.setSetting(SETTING_TRAKT_ACCESS_TOKEN, '')
      xbmc.executebuiltin(u'Notification(%s,%s)' % (addon_name, ' Trakt Cleared'))
def refresh_trakt():
    ret =xbmcgui.Dialog().yesno(("Authenticate Trakt"), ("ReAuthenticate?"))
    if ret:
      Addon.setSetting(SETTING_TRAKT_ACCESS_TOKEN, '')
      xbmc.executebuiltin(u'Notification(%s,%s)' % (addon_name, ' Trakt Cleared'))
      trakt_authenticate()
      xbmc.executebuiltin(u'Notification(%s,%s)' % (addon_name, ' Done'))
def trakt_get_device_code():
    data = { 'client_id': CLIENT_ID }
    return call_trakt("oauth/device/code", data=data, with_auth=False)
def trakt_authenticate():
    code = trakt_get_device_code()
    token = trakt_get_device_token(code)
    log.warning(token)
    if token and 'error_code' not in token:
        expires_at = time.time() + token["expires_in"]
        Addon.setSetting(SETTING_TRAKT_EXPIRES_AT, str(expires_at))
        Addon.setSetting(SETTING_TRAKT_ACCESS_TOKEN, token["access_token"])
        Addon.setSetting(SETTING_TRAKT_REFRESH_TOKEN, token["refresh_token"])
        return True
    return False
def trakt_refresh_token():
    data = {        
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
        "grant_type": "refresh_token",
        "refresh_token": (Addon.getSetting(SETTING_TRAKT_REFRESH_TOKEN))
    }
    response = call_trakt("oauth/token", data=data, with_auth=False)
    if response:
        Addon.setSetting(SETTING_TRAKT_ACCESS_TOKEN, response["access_token"])
        Addon.setSetting(SETTING_TRAKT_REFRESH_TOKEN, response["refresh_token"])
def copy2clip(txt):
    import subprocess,sys
    platform = sys.platform

    if platform == 'win32':
        try:
            cmd = 'echo ' + txt.strip() + '|clip'
            subprocess.check_call(cmd, shell=True)
            return True
            pass
        except:
            pass
    elif platform == 'linux2':
        try:
            from subprocess import Popen, PIPE
            p = Popen(['xsel', '-pi'], stdin=PIPE)
            p.communicate(input=txt)
            return True
        except:
            pass
    else:
        return None
        pass
    pass
    
def trakt_get_device_token(device_codes):
    
    data = {
        "code": device_codes["device_code"],
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    start=time.time()
    expires_in = device_codes["expires_in"]
    if Addon.getSetting("auto_trk")=='true':
        from trk_aut import auto_trk_auth
        auto_trk_auth(str(device_codes["user_code"]))
    else:
        progress_dialog = xbmcgui.DialogProgress()
        if copy2clip(str(device_codes["user_code"])):
            add_t='This code has been copied to your clipboard'
        else:
            add_t=''
        progress_dialog.create(("Authenticate Trakt"), ("Please go to https://trakt.tv/activate and enter the code")+'\n'+add_t+'\n'+str(device_codes["user_code"])    )
    
        
    try:
        time_passed = 0
        try:
            ab_req=xbmc.abortRequested()
        except:
            monit = xbmc.Monitor()
            ab_req=monit.abortRequested()
        log.warning('while::') 
        while not ab_req and  time_passed < expires_in:        
            
            if progress_dialog.iscanceled():
                    break
            try:
                response = call_trakt("oauth/device/token", data=data, with_auth=False)
                log.warning('response')
                log.warning(response)
                if 'error_code' in response:
                    progress = int(100 * time_passed / expires_in)
                    progress_dialog.update(progress)
                    xbmc.sleep(max(device_codes["interval"], 1)*1000)
                else:
                    return response
            except :
                
                
                progress = int(100 * time_passed / expires_in)
                progress_dialog.update(progress)
                xbmc.sleep(max(device_codes["interval"], 1)*1000)
            
            time_passed = time.time() - start
    finally:
        
            progress_dialog.close()
            del progress_dialog
    return None




def post_trakt(path,data=None, with_auth=True):
    import urllib
    
    API_ENDPOINT = "https://api.trakt.tv"

    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': CLIENT_ID
    }


    
    if with_auth:
           
            token =( Addon.getSetting(SETTING_TRAKT_ACCESS_TOKEN))
            headers.update({'Authorization': 'Bearer %s' % token})
            
        
            return get_html("{0}/{1}".format(API_ENDPOINT, path), json=(data), headers=headers).content()
  
        
      
def cached_call_t(path, params={}, data=None, is_delete=False, with_auth=True, pagination = False, page = 1):
    import urllib
    
    params = dict([(k, (v).encode('utf8')) for k, v in params.items() if v])
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': CLIENT_ID
    }
    API_ENDPOINT = "https://api.trakt.tv"
    
    def send_query():
        if with_auth:
            try:
                expires_at = int(Addon.getSetting(SETTING_TRAKT_EXPIRES_AT))
                if time.time() > expires_at:
                    trakt_refresh_token()
            except:
                pass
            token =( Addon.getSetting(SETTING_TRAKT_ACCESS_TOKEN))
            if token:
                headers['Authorization'] = 'Bearer ' + token
        if data is not None:
            assert not params
            log.warning("trakt addr")
            log.warning("{0}/{1}".format(API_ENDPOINT, path))
            log.warning(data)
            log.warning(headers)
            res=get_html("{0}/{1}".format(API_ENDPOINT, path), json=(data), headers=headers,timeout=15).json()
            log.warning(res)
            return res
        elif is_delete:
            import sys
            path1=xbmc_tranlate_path('special://home/addons/script.module.requests/lib')
            sys.path.append( path1)
            path1=xbmc_tranlate_path('special://home/addons/script.module.urllib3/lib')
            sys.path.append( path1)
            path1=xbmc_tranlate_path('special://home/addons/script.module.chardet/lib')
            sys.path.append( path1)
            path1=xbmc_tranlate_path('special://home/addons/script.module.certifi/lib')
            sys.path.append( path1)
            path1=xbmc_tranlate_path('special://home/addons/script.module.idna/lib')
            sys.path.append( path1)
            path1=xbmc_tranlate_path('special://home/addons/script.module.futures/lib')
            sys.path.append( path1)
            import requests
            return requests.delete("{0}/{1}".format(API_ENDPOINT, path), headers=headers,timeout=15)
        else:
           
            a=get_html("{0}/{1}".format(API_ENDPOINT, path), params, headers=headers,timeout=15).json()
            return a

    def paginated_query(page):
        lists = []
        params['page'] = page
        results = send_query()

        if with_auth and results.status_code == 401 and xbmcgui.Dialog().yesno(("Authenticate Trakt"), ("You must authenticate2 with Trakt. Do you want to authenticate now?")) and trakt_authenticate():
            response = paginated_query(1)
            return response
        results.raise_for_status()
        results.encoding = 'utf-8'
        lists.extend(results.json())
        return lists, results.headers["X-Pagination-Page-Count"]
if pagination == False:
        response = send_query()
        status_code=200
        if 'error_code' in response:
            status_code=response['error_code']
        log.warning(status_code)
        log.warning(with_auth)
        check=False
        if Addon.getSetting("auto_trk")=='true':
            check=True
        else:
            x=Addon.getSetting(SETTING_TRAKT_ACCESS_TOKEN)
            if with_auth and status_code == 401:
                check=xbmcgui.Dialog().yesno(("Authenticate Trakt"),("You must authenticate with1 Trakt. Do you want to authenticate now?"))
        if with_auth and status_code == 401 and check and trakt_authenticate():
            response = send_query()
        #response.raise_for_status()
       
        return response
    else:
        
        (response, numpages) = paginated_query(page)
        return response, numpages
def call_trakt(path, params={}, data=None, is_delete=False, with_auth=True, pagination = False, page = 1):
    a=cached_call_t(path, params, data, is_delete, with_auth, pagination,  page)
    return a
def base_convert(x,b,alphabet='0123456789abcdefghijklmnopqrstuvwxyz'):
    'convert an integer to its string representation in a given base'
    if b<2 or b>len(alphabet):
        if b==64: # assume base64 rather than raise error
            alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        else:
            raise AssertionError("int2base base out of range")
    if isinstance(x,complex): # return a tuple
        return ( int2base(x.real,b,alphabet) , int2base(x.imag,b,alphabet) )
    if x<=0:
        if x==0:
            return alphabet[0]
        else:
            return  '-' + int2base(-x,b,alphabet)
    # else x is non-negative real
    rets=''
    while x>0:
        x,idx = divmod(x,b)
        rets = alphabet[idx] + rets
    return rets
def parseDOM(html, name='', attrs=None, ret=False):
    import dom_parser
    if attrs: attrs = dict((key, re.compile(value + ('$' if value else ''))) for key, value in attrs.iteritems())
    results = dom_parser.parse_dom(html, name, attrs, ret)
    if ret:
        results = [result.attrs[ret.lower()] for result in results]
    else:
        results = [result.content for result in results]
    return results
def fix_q(quality):
    f_q=100
    if quality.lower()=='4k':
        quality='2160'
    if '2160' in quality:
      f_q=1
    if '1080' in quality:
      f_q=2
    elif '720' in quality:
      f_q=3
    elif '480' in quality:
      f_q=4
    elif 'hd' in quality.lower() or 'hq' in quality.lower():
      f_q=5
    elif '360' in quality or 'sd' in quality.lower():
      f_q=6
    elif '240' in quality:
      f_q=7
   
        
    return f_q
def base_convert(x,b,alphabet='0123456789abcdefghijklmnopqrstuvwxyz'):
    'convert an integer to its string representation in a given base'
    if b<2 or b>len(alphabet):
        if b==64: # assume base64 rather than raise error
            alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        else:
            raise AssertionError("int2base base out of range")
    if isinstance(x,complex): # return a tuple
        return ( int2base(x.real,b,alphabet) , int2base(x.imag,b,alphabet) )
    if x<=0:
        if x==0:
            return alphabet[0]
        else:
            return  '-' + int2base(-x,b,alphabet)
    # else x is non-negative real
    rets=''
    while x>0:
        x,idx = divmod(x,b)
        rets = alphabet[idx] + rets
    return rets
    
def get_imdb_data(info,name_o,image,source,type):
         
         tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
         name=name_o
         imdb_id=''
         icon=image
         fanart=image
         plot=''
         rating=''
         genere=' '
         check=False
         if source=='4k':
            if  Addon.getSetting("4k_tmdb")=='false':
              check=True
         else:
            if source=='jen2':
                check=True
            elif  Addon.getSetting("jen_tmdb")=='false':
             check=True
         if check:
            return name,imdb_id,icon,fanart,plot,rating,genere
         if 'title' in info:
          a=info['title']
         else:
           info['title']=name_o.replace('.',' ')
         
         if len(info['title'])>0:
          a=a
         else:
           info['title']=name_o.replace('.',' ')
         if 1:
          if 'year' in info:
            tmdb_data=f"https://api.themoviedb.org/3/search/%s?api_key={tmdb_key}&query=%s&year=%s&language={lang}&append_to_response=external_ids"%(type,urllib.quote_plus(info['title']),info['year'])
            year_n=info['year']
          else:
            tmdb_data=f"https://api.themoviedb.org/3/search/%s?api_key={tmdb_key}&query=%s&language={lang}&append_to_response=external_ids"%(type,urllib.quote_plus(info['title']))

          all_data=get_html(tmdb_data).json()
          if 'results' in all_data:
           if len(all_data['results'])>0:
                if (all_data['results'][0]['id'])!=None:
                    url=f'https://api.themoviedb.org/3/%s/%s?api_key={tmdb_key}&language={lang}&append_to_response=external_ids'%(type,all_data['results'][0]['id'])
                    try:
                        all_d2=get_html(url).json()
                        imdb_id=all_d2['external_ids']['imdb_id']
                    except:
                        imdb_id=" "
                    genres_list= []
                    if 'genres' in all_d2:
                        for g in all_d2['genres']:
                          genres_list.append(g['name'])
                    
                    try:genere = u' / '.join(genres_list)
                    except:genere=''
                
                try:
                        if 'title' in all_data['results'][0]:
                          name=all_data['results'][0]['title']
                        else:
                          name=all_data['results'][0]['name']
                        rating=all_data['results'][0]['vote_average']
                        try:
                          icon=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['poster_path']
                          fanart=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['backdrop_path']
                        except:
                         pass
                        
                        plot=all_data['results'][0]['overview']
                except Exception as e:
                        
                        name=info['title']
                        fanart=' '
                        icon=' '
                        plot=' '
          else:
               name=name_o
               fanart=image
               icon=image
               plot=' '
         else:
               name=name_o
               fanart=image
               icon=image
               plot=' '
       
         return name,imdb_id,icon,fanart,plot,rating,genere
         
def fix_name(name_o):
    
    regex_c='\[COLOR(.+?)\]'
    match_c=re.compile(regex_c).findall(name_o)
    if len(match_c)>0:
          for items in match_c:
            name_o=name_o.replace('[COLOR%s]'%items,'')
    name_o=name_o.replace('=',' ').replace('[B]','').replace('[/B]','').replace('silver
