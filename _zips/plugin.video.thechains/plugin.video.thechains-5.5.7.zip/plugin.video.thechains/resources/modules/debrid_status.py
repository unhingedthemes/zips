# -*- coding: utf-8 -*-
"""The Chains - Debrid Services account status helper.

Queries every debrid backend (Real-Debrid, Premiumize, AllDebrid,
TorBox) for the user's authorisation state and premium expiry, and
exposes a single dialog card that surfaces the result inside the addon
settings.

It is also used by service.py to fire a one-shot-per-day toast when any
debrid subscription is within the final 7-day window.
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

try:
    import urllib.request as _urlreq
except Exception:  # pragma: no cover
    import urllib2 as _urlreq

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
NOTIF_FILE = os.path.join(PROFILE_DIR, 'debrid_notif_state.json')

HTTP_TIMEOUT = 10
EXPIRY_WARN_DAYS = 7
LOG_TAG = '[%s.debrid_status]' % ADDON_ID


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('%s %s' % (LOG_TAG, msg), level)
    except Exception:
        pass


def _http_json(url, headers=None, timeout=HTTP_TIMEOUT):
    headers = headers or {}
    req = _urlreq.Request(url, headers=headers)
    with _urlreq.urlopen(req, timeout=timeout) as r:
        body = r.read().decode('utf-8', errors='replace')
    return json.loads(body)


def _fmt_expiry(ts):
    if not ts:
        return ''
    try:
        return time.strftime('%Y-%m-%d %H:%M', time.localtime(int(ts)))
    except Exception:
        return ''


def _days_remaining(expiry_ts):
    if not expiry_ts:
        return None
    try:
        return int((float(expiry_ts) - time.time()) / 86400.0)
    except Exception:
        return None


# ---------------------------------------------------------------- providers
def _check_real_debrid():
    info = {'name': 'Real-Debrid', 'authorised': False, 'expiry_ts': 0,
            'expiry_str': '', 'days': None, 'detail': ''}
    token = ADDON.getSetting('rd.auth') or ''
    if ADDON.getSetting('debrid_use_rd') != 'true' or not token:
        info['detail'] = 'Not enabled' if ADDON.getSetting('debrid_use_rd') != 'true' else 'Not authorised'
        return info
    try:
        data = _http_json(
            'https://api.real-debrid.com/rest/1.0/user',
            headers={'Authorization': 'Bearer %s' % token,
                     'User-Agent': 'TheChains/%s' % ADDON.getAddonInfo('version')})
        exp_iso = data.get('expiration') or ''
        if exp_iso:
            try:
                t = time.strptime(exp_iso[:19], '%Y-%m-%dT%H:%M:%S')
                ts = time.mktime(t)
                info['expiry_ts'] = ts
                info['expiry_str'] = _fmt_expiry(ts)
                info['days'] = _days_remaining(ts)
            except Exception:
                info['expiry_str'] = exp_iso
        info['authorised'] = bool(data.get('premium', 0)) or bool(exp_iso)
        info['detail'] = 'Premium' if info['authorised'] else 'Free / expired'
    except Exception as e:
        info['detail'] = 'Error: %s' % e
        log('real-debrid: %s' % e, xbmc.LOGERROR)
    return info


def _check_premiumize():
    info = {'name': 'Premiumize', 'authorised': False, 'expiry_ts': 0,
            'expiry_str': '', 'days': None, 'detail': ''}
    token = ADDON.getSetting('premiumize.token') or ''
    if ADDON.getSetting('debrid_use_pm') != 'true' or not token:
        info['detail'] = 'Not enabled' if ADDON.getSetting('debrid_use_pm') != 'true' else 'Not authorised'
        return info
    try:
        data = _http_json(
            'https://www.premiumize.me/api/account/info',
            headers={'Authorization': 'Bearer %s' % token,
                     'User-Agent': 'TheChains/%s' % ADDON.getAddonInfo('version')})
        if (data or {}).get('status') != 'success':
            info['detail'] = 'Error: %s' % (data.get('message', 'unknown'))
            return info
        ts = data.get('premium_until') or 0
        info['expiry_ts'] = ts
        info['expiry_str'] = _fmt_expiry(ts)
        info['days'] = _days_remaining(ts)
        info['authorised'] = ts and ts > time.time()
        info['detail'] = 'Premium' if info['authorised'] else 'Free / expired'
    except Exception as e:
        info['detail'] = 'Error: %s' % e
        log('premiumize: %s' % e, xbmc.LOGERROR)
    return info


def _check_alldebrid():
    info = {'name': 'AllDebrid', 'authorised': False, 'expiry_ts': 0,
            'expiry_str': '', 'days': None, 'detail': ''}
    token = ADDON.getSetting('alldebrid.token') or ''
    if ADDON.getSetting('debrid_use_ad') != 'true' or not token:
        info['detail'] = 'Not enabled' if ADDON.getSetting('debrid_use_ad') != 'true' else 'Not authorised'
        return info
    try:
        url = ('https://api.alldebrid.com/v4/user?agent=%s&apikey=%s'
               % ('TheChains', token))
        data = _http_json(url, headers={
            'User-Agent': 'TheChains/%s' % ADDON.getAddonInfo('version')})
        user = ((data or {}).get('data') or {}).get('user') or {}
        ts = user.get('premiumUntil') or 0
        info['expiry_ts'] = ts
        info['expiry_str'] = _fmt_expiry(ts)
        info['days'] = _days_remaining(ts)
        info['authorised'] = bool(user.get('isPremium')) or (ts and ts > time.time())
        info['detail'] = 'Premium' if info['authorised'] else 'Free / expired'
    except Exception as e:
        info['detail'] = 'Error: %s' % e
        log('alldebrid: %s' % e, xbmc.LOGERROR)
    return info


def _check_torbox():
    info = {'name': 'TorBox', 'authorised': False, 'expiry_ts': 0,
            'expiry_str': '', 'days': None, 'detail': ''}
    token = ADDON.getSetting('tb.token') or ''
    if ADDON.getSetting('debrid_use_tr') != 'true' or not token:
        info['detail'] = 'Not enabled' if ADDON.getSetting('debrid_use_tr') != 'true' else 'Not authorised'
        return info
    try:
        data = _http_json(
            'https://api.torbox.app/v1/api/user/me',
            headers={'Authorization': 'Bearer %s' % token,
                     'User-Agent': 'TheChains/%s' % ADDON.getAddonInfo('version')})
        user = (data or {}).get('data') or {}
        exp = user.get('premium_expires_at') or user.get('plan_expires_at') or ''
        ts = 0
        if isinstance(exp, (int, float)):
            ts = float(exp)
        elif isinstance(exp, str) and exp:
            try:
                t = time.strptime(exp[:19], '%Y-%m-%dT%H:%M:%S')
                ts = time.mktime(t)
            except Exception:
                pass
        info['expiry_ts'] = ts
        info['expiry_str'] = _fmt_expiry(ts) if ts else (exp if isinstance(exp, str) else '')
        info['days'] = _days_remaining(ts)
        plan = user.get('plan') or 0
        info['authorised'] = bool(plan) or (ts and ts > time.time())
        info['detail'] = ('Plan %s' % plan) if plan else ('Premium' if info['authorised'] else 'Free / expired')
    except Exception as e:
        info['detail'] = 'Error: %s' % e
        log('torbox: %s' % e, xbmc.LOGERROR)
    return info


def gather():
    """Return the status list for every supported debrid service."""
    return [
        _check_real_debrid(),
        _check_premiumize(),
        _check_alldebrid(),
        _check_torbox(),
    ]


# ---------------------------------------------------------------- UI
def _row(svc):
    name = svc['name']
    if not svc['authorised']:
        return '[B]%s[/B]  [COLOR red]\u25CF Not authorised[/COLOR]  [COLOR lightgray]%s[/COLOR]' % (
            name, svc.get('detail', ''))
    days = svc.get('days')
    if days is None:
        colour = 'lightgreen'
        tail = svc.get('detail', '')
    elif days < 0:
        colour = 'red'
        tail = 'EXPIRED %s' % svc.get('expiry_str', '')
    elif days <= EXPIRY_WARN_DAYS:
        colour = 'orange'
        tail = '%d day%s left  (expires %s)' % (
            days, '' if days == 1 else 's', svc.get('expiry_str', ''))
    else:
        colour = 'lightgreen'
        tail = '%d days left  (expires %s)' % (days, svc.get('expiry_str', ''))
    return '[B]%s[/B]  [COLOR %s]\u25CF Authorised[/COLOR]  [COLOR %s]%s[/COLOR]' % (
        name, colour, colour, tail)


def show_dialog():
    services = gather()
    body = '\n\n'.join(_row(s) for s in services)
    legend = ('\n\n[COLOR lightgray][I]Green = healthy, '
              'Orange = within %d days, '
              'Red = expired or not authorised.[/I][/COLOR]'
              % EXPIRY_WARN_DAYS)
    try:
        xbmcgui.Dialog().textviewer(
            '%s - Debrid Services Account' % ADDON_NAME,
            body + legend)
    except Exception:
        xbmcgui.Dialog().ok(
            '%s - Debrid Services Account' % ADDON_NAME,
            body + legend)


# ---------------------------------------------------------------- Service watcher
def _load_state():
    try:
        if os.path.exists(NOTIF_FILE):
            with open(NOTIF_FILE, 'r', encoding='utf-8') as f:
                return json.load(f) or {}
    except Exception as e:
        log('load state: %s' % e, xbmc.LOGERROR)
    return {}


def _save_state(state):
    try:
        d = os.path.dirname(NOTIF_FILE)
        if d and not os.path.exists(d):
            os.makedirs(d)
        with open(NOTIF_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        log('save state: %s' % e, xbmc.LOGERROR)


def check_and_notify(icon=None, force=False):
    """Fire a toast for any authorised debrid that has \u22647 days left.

    Notifies at most once per service per UTC day to avoid spamming. Set
    ``force=True`` to bypass the once-a-day guard.
    """
    state = _load_state()
    today = time.strftime('%Y-%m-%d', time.gmtime())
    fired = []
    for svc in gather():
        if not svc['authorised']:
            continue
        days = svc.get('days')
        if days is None or days < 0 or days > EXPIRY_WARN_DAYS:
            continue
        last = state.get(svc['name'])
        if not force and last == today:
            continue
        title = '%s - %s expiring' % (ADDON_NAME, svc['name'])
        msg = '%d day%s left (expires %s)' % (
            days, '' if days == 1 else 's', svc.get('expiry_str', ''))
        try:
            xbmcgui.Dialog().notification(title, msg,
                                          icon or xbmcgui.NOTIFICATION_WARNING,
                                          7000, False)
        except Exception as e:
            log('notify error: %s' % e, xbmc.LOGERROR)
        state[svc['name']] = today
        fired.append(svc['name'])
    if fired:
        _save_state(state)
    return fired
