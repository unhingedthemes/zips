# -*- coding: utf-8 -*-
"""The Chains - Debug Bundle.

Collects everything useful for diagnosing addon problems and writes it as
a single zip into the user's Downloads folder. Optionally uploads the zip
anonymously to gofile.io and copies the share URL to the clipboard /
shows it on screen.

The bundle contains:
    * Kodi log (kodi.log + kodi.old.log)
    * Addon settings (settings.xml from the user profile + bundled one)
    * addon.xml (version, requires, etc.)
    * whatsnew.json + whatsnew_auto.json + whatsnew_seen.json
    * File listing with sizes and SHA-1 checksums for every addon file
    * Network probe results (DNS + HTTP HEAD on the source URLs used by
      the main menu)
    * A debug_summary.txt with platform info, python version, kodi build
      and any exception that happened while collecting the data.
"""
import hashlib
import json
import os
import platform
import re
import sys
import time
import traceback
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

try:
    import urllib.request as _urlreq
except Exception:  # pragma: no cover
    import urllib2 as _urlreq

try:
    from urllib.parse import urlparse
except Exception:  # pragma: no cover
    from urlparse import urlparse


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
LOG_TAG = '[%s.debug]' % ADDON_ID

GOFILE_API = 'https://api.gofile.io'


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('%s %s' % (LOG_TAG, msg), level)
    except Exception:
        pass


# ---------------------------------------------------------------- helpers
def _kodi_log_dir():
    return xbmcvfs.translatePath('special://logpath')


def _default_download_dir():
    """Best-effort cross-platform Downloads directory."""
    custom = ADDON.getSetting('debug_download_dir') or ''
    custom = custom.strip()
    if custom:
        return xbmcvfs.translatePath(custom)
    # Android
    android = '/storage/emulated/0/Download'
    if os.path.isdir(android):
        return android
    home = os.path.expanduser('~')
    for cand in ('Downloads', 'Download', 'Desktop'):
        p = os.path.join(home, cand)
        if os.path.isdir(p):
            return p
    return home


def _safe_copy_to_zip(zf, src, arcname):
    try:
        if os.path.exists(src):
            zf.write(src, arcname)
            return True
    except Exception as e:
        log('zip add %s failed: %s' % (src, e), xbmc.LOGERROR)
    return False


def _sha1(path, chunk=65536):
    h = hashlib.sha1()
    try:
        with open(path, 'rb') as f:
            for blk in iter(lambda: f.read(chunk), b''):
                h.update(blk)
        return h.hexdigest()
    except Exception:
        return ''


def _walk_addon_files():
    rows = []
    for root, _dirs, files in os.walk(ADDON_PATH):
        for fn in files:
            fp = os.path.join(root, fn)
            try:
                size = os.path.getsize(fp)
            except Exception:
                size = -1
            rows.append({
                'path': os.path.relpath(fp, ADDON_PATH),
                'size': size,
                'sha1': _sha1(fp) if size >= 0 and size < 5_000_000 else '',
            })
    return rows


def _menu_urls_from_menus_py():
    urls = []
    try:
        path = os.path.join(ADDON_PATH, 'resources', 'menus.py')
        with open(path, 'r', encoding='utf-8') as f:
            src = f.read()
        for u in re.findall(r"https?://[^'\"\s)]+", src):
            urls.append(u)
    except Exception:
        pass
    # Dedupe, keep order
    seen = set()
    out = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _probe_url(url, timeout=8):
    info = {'url': url, 'ok': False, 'status': None, 'error': None,
            'elapsed_ms': None}
    start = time.time()
    try:
        req = _urlreq.Request(url, method='HEAD',
                              headers={'User-Agent': 'TheChains-Debug/%s'
                                                     % ADDON_VERSION})
        with _urlreq.urlopen(req, timeout=timeout) as r:
            info['status'] = r.status
            info['ok'] = 200 <= r.status < 400
    except Exception as e:
        info['error'] = '%s: %s' % (type(e).__name__, e)
    info['elapsed_ms'] = int((time.time() - start) * 1000)
    return info


def _resolver_status():
    out = {}
    for mod_name in ('all_debrid', 'real_debrid', 'premiumize',
                     'torbox_api', 'furk_api'):
        try:
            __import__('resources.modules.' + mod_name)
            out[mod_name] = 'import_ok'
        except Exception as e:
            out[mod_name] = 'IMPORT_FAIL: %s: %s' % (type(e).__name__, e)
    return out


def _platform_info():
    return {
        'addon_id': ADDON_ID,
        'addon_version': ADDON_VERSION,
        'kodi_build': xbmc.getInfoLabel('System.BuildVersion'),
        'kodi_version_major': xbmc.getInfoLabel('System.BuildVersion').split('.', 1)[0],
        'python': sys.version,
        'platform': platform.platform(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'addon_path': ADDON_PATH,
        'profile_dir': PROFILE_DIR,
        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
    }


# ---------------------------------------------------------------- gofile
def _gofile_best_server(timeout=10):
    """Query gofile.io for the best upload server. Returns e.g. 'store2'."""
    try:
        from urllib.request import Request, urlopen
        req = Request(GOFILE_API + '/servers',
                      headers={'User-Agent': 'TheChains-Debug/' + ADDON_VERSION})
        with urlopen(req, timeout=timeout) as r:
            resp = json.loads(r.read().decode('utf-8'))
        if resp.get('status') == 'ok':
            servers = resp.get('data', {}).get('servers', [])
            if servers:
                # Prefer the first listed server
                return servers[0].get('name') or 'store1'
        return 'store1'
    except Exception as e:
        log('gofile servers err: %s' % e, xbmc.LOGINFO)
        return 'store1'


def _gofile_upload(file_path, timeout=180):
    """Upload to gofile anonymously. Returns the public download page URL.

    Flow:
      1. GET https://api.gofile.io/servers  -> pick best
      2. POST https://{server}.gofile.io/contents/uploadfile (multipart)
    """
    try:
        import uuid
        from urllib.request import Request, urlopen
        server = _gofile_best_server()
        endpoint = 'https://%s.gofile.io/contents/uploadfile' % server

        boundary = '----TheChains' + uuid.uuid4().hex
        with open(file_path, 'rb') as f:
            payload = f.read()
        body_parts = []
        body_parts.append(('--' + boundary).encode())
        body_parts.append(
            ('Content-Disposition: form-data; name="file"; filename="%s"'
             % os.path.basename(file_path)).encode())
        body_parts.append(b'Content-Type: application/zip')
        body_parts.append(b'')
        body_parts.append(payload)
        body_parts.append(('--' + boundary + '--').encode())
        body_parts.append(b'')
        data = b'\r\n'.join(body_parts)

        req = Request(endpoint, data=data,
                      headers={
                          'Content-Type': 'multipart/form-data; boundary=' + boundary,
                          'User-Agent': 'TheChains-Debug/' + ADDON_VERSION,
                      })
        with urlopen(req, timeout=timeout) as r:
            resp = json.loads(r.read().decode('utf-8'))
        if resp.get('status') == 'ok':
            d = resp.get('data', {})
            return d.get('downloadPage') or d.get('directLink') or ''
        return 'ERR: %s' % resp
    except Exception as e:
        return 'ERR: %s: %s' % (type(e).__name__, e)


# ---------------------------------------------------------------- public
def build_bundle(progress=True):
    """Create the zip and return (zip_path, upload_url_or_empty)."""
    dlg = None
    if progress:
        dlg = xbmcgui.DialogProgress()
        dlg.create('%s - Debug Bundle' % ADDON_NAME, 'Collecting...')

    target_dir = _default_download_dir()
    try:
        os.makedirs(target_dir, exist_ok=True)
    except Exception:
        target_dir = PROFILE_DIR

    fname = 'thechains-debug-%s.zip' % time.strftime('%Y%m%d-%H%M%S')
    zip_path = os.path.join(target_dir, fname)

    summary_lines = []
    summary_lines.append('=== The Chains Debug Bundle ===')
    info = _platform_info()
    for k, v in info.items():
        summary_lines.append('%s: %s' % (k, v))

    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # 1. Kodi logs
            if dlg: dlg.update(10, 'Collecting Kodi logs...')
            log_dir = _kodi_log_dir()
            for log_name in ('kodi.log', 'kodi.old.log',
                             'spmc.log', 'spmc.old.log'):
                _safe_copy_to_zip(zf, os.path.join(log_dir, log_name),
                                  'logs/' + log_name)

            # 2. Settings + addon.xml
            if dlg: dlg.update(25, 'Collecting settings...')
            _safe_copy_to_zip(zf,
                              os.path.join(PROFILE_DIR, 'settings.xml'),
                              'settings/user_settings.xml')
            _safe_copy_to_zip(zf,
                              os.path.join(ADDON_PATH, 'resources',
                                           'settings.xml'),
                              'settings/default_settings.xml')
            _safe_copy_to_zip(zf,
                              os.path.join(ADDON_PATH, 'addon.xml'),
                              'settings/addon.xml')

            # 3. What's New state
            if dlg: dlg.update(40, 'Collecting What\'s New state...')
            for fn in ('whatsnew.json',):
                _safe_copy_to_zip(zf, os.path.join(ADDON_PATH, fn),
                                  'whatsnew/' + fn)
            for fn in ('whatsnew_auto.json', 'whatsnew_seen.json',
                       'whatsnew_remote.json', 'menu_snapshot.json'):
                _safe_copy_to_zip(zf, os.path.join(PROFILE_DIR, fn),
                                  'whatsnew/' + fn)

            # 4. File listing + checksums
            if dlg: dlg.update(55, 'Hashing addon files...')
            files = _walk_addon_files()
            zf.writestr('manifest/files.json',
                        json.dumps(files, indent=2))

            # 5. Network probes
            if dlg: dlg.update(75, 'Probing network...')
            urls = _menu_urls_from_menus_py()[:30]
            probes = [_probe_url(u) for u in urls]
            zf.writestr('network/probes.json',
                        json.dumps(probes, indent=2))

            # 6. Resolver / module sanity
            if dlg: dlg.update(88, 'Checking resolvers...')
            zf.writestr('modules/import_status.json',
                        json.dumps(_resolver_status(), indent=2))

            # 7. Summary
            zf.writestr('debug_summary.txt', '\n'.join(summary_lines))
    except Exception as e:
        log('bundle build error: %s\n%s' % (e, traceback.format_exc()),
            xbmc.LOGERROR)
        if dlg: dlg.close()
        raise

    if dlg: dlg.update(95, 'Uploading to GoFile...')
    upload_url = ''
    try:
        if ADDON.getSetting('debug_upload_gofile') != 'false':
            upload_url = _gofile_upload(zip_path)
    except Exception as e:
        upload_url = 'ERR: %s' % e
    if dlg: dlg.update(100, 'Done')
    if dlg: dlg.close()
    return zip_path, upload_url


def run(show_dialog=True):
    """Entry point used by mode 251 and Ctrl+D."""
    try:
        zip_path, upload = build_bundle(progress=show_dialog)
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Debug bundle failed',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        log('debug.run failed: %s' % e, xbmc.LOGERROR)
        return

    msg_lines = ['Saved: %s' % zip_path]
    if upload and not upload.startswith('ERR'):
        msg_lines.append('GoFile: %s' % upload)
    elif upload:
        msg_lines.append('Upload failed: %s' % upload)

    if show_dialog:
        xbmcgui.Dialog().textviewer(
            '%s - Debug Bundle' % ADDON_NAME,
            '\n\n'.join(msg_lines))
    else:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Debug saved: %s' % os.path.basename(zip_path),
            xbmcgui.NOTIFICATION_INFO, 6000)
    return zip_path, upload
