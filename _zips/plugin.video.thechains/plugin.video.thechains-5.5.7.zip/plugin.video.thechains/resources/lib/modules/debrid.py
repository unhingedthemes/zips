# -*- coding: utf-8 -*-

'''
    Genesis Add-on
    Copyright (C) 2015 lambda

    -Mofidied by The Crew
    -Copyright (C) 2019 The Crew

    -Modified 2026: filter debrid resolvers to only those the user has
     enabled + authorized, to prevent unauthorized resolvers from
     popping up device-code authorization dialogs during scraping.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
'''
from resources.lib.modules import control, log_utils


# Map resolveurl resolver display names -> The Chains setting toggles
_DEBRID_TOGGLES = {
    'Real-Debrid':   'debrid_use_rd',
    'Premiumize.me': 'debrid_use_pm',
    'AllDebrid':     'debrid_use_ad',
    'TorBox':        'debrid_use_tr',
}


def _is_authorized(resolver):
    """Best-effort check that a resolveurl resolver actually has credentials.

    We avoid calling resolver.login() (which can pop a device-code dialog).
    Instead we look at common setting fields; if none of them carry a value
    we treat the resolver as not-authorized and exclude it.
    """
    try:
        get = resolver.get_setting
    except Exception:
        return False
    for key in ('token', 'refresh', 'client_id', 'password', 'login',
                'username', 'apikey', 'api_key'):
        try:
            val = get(key)
        except Exception:
            val = ''
        if val and str(val).strip().lower() not in ('', 'false', '0'):
            return True
    return False


def _user_enables(resolver_name):
    """Check the user's per-resolver toggle in The Chains settings."""
    setting_id = _DEBRID_TOGGLES.get(resolver_name)
    if not setting_id:
        # Unknown resolver: keep it (rapidgator etc.) but rely on
        # _is_authorized() to gate it.
        return True
    val = control.setting(setting_id)
    if val is None or val == '':
        return False
    return str(val).lower() == 'true'


def _master_enabled():
    val = control.setting('debrid_use')
    if val is None or val == '':
        return True  # backward compat: assume on
    return str(val).lower() == 'true'


try:
    import resolveurl

    _all_universal = [r() for r in resolveurl.relevant_resolvers(order_matters=True)
                      if r.isUniversal()]

    if _master_enabled():
        debrid_resolvers = [r for r in _all_universal
                            if _user_enables(r.name) and _is_authorized(r)]
    else:
        debrid_resolvers = []

    if len(debrid_resolvers) == 0:
        # Support Rapidgator accounts! Unfortunately, `sources.py` assumes
        # that rapidgator.net is only ever accessed via a debrid service,
        # so we add rapidgator as a debrid resolver and everything just
        # works. As a bonus(?), rapidgator links will be highlighted just
        # like actual debrid links.
        try:
            debrid_resolvers = [r() for r in resolveurl.relevant_resolvers(
                order_matters=True, include_universal=False)
                if 'rapidgator.net' in r.domains]
        except Exception:
            debrid_resolvers = []

except Exception:
    debrid_resolvers = []


def status(torrent=False):
    debrid_check = debrid_resolvers != []
    if debrid_check is True:
        if torrent:
            enabled = control.setting('torrent.enabled')
            if enabled == '' or enabled.lower() == 'true':
                return True
            else:
                return False
    return debrid_check


def resolver(url, debrid):
    try:
        debrid_resolver = [r for r in debrid_resolvers if r.name == debrid][0]

        # Only call login() for resolvers we already know are authorized.
        # _is_authorized() filtering above prevents the device-code popup.
        debrid_resolver.login()
        _host, _media_id = debrid_resolver.get_host_and_id(url)
        stream_url = debrid_resolver.get_media_url(_host, _media_id)

        return stream_url
    except Exception as e:
        log_utils.log('%s Resolve Failure: %s' % (debrid, e), log_utils.LOGWARNING)
        return None
