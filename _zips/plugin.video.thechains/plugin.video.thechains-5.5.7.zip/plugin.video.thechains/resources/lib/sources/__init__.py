# -*- coding: utf-8 -*-

'''
    Genesis Add-on
    Copyright (C) 2015 lambda

    -Mofidied by The Crew
    -Copyright (C) 2019 lambda

    -Modified 2026: optionally route source discovery through external
     scraper modules (CocoScrapers and/or Gears Scrapers). When at least
     one external scraper is enabled in addon settings, the internal
     scrapers are completely skipped to avoid interference.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
'''

import os
import os.path
import logging
import pkgutil

from resources.lib.modules import log_utils

try:
    from resources.lib.modules import control
except Exception:
    control = None

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmc = xbmcaddon = xbmcvfs = None


__all__ = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
logging.warning(__all__)


# Candidate addon ids for each external scraper, in priority order.
# We try each until one imports successfully.
_COCO_CANDIDATES = ['script.module.cocoscrapers']
_GEARS_CANDIDATES = [
    'script.module.gearsscraper',
    'script.module.gearsscrapers',
    'script.module.gears',
]


def _setting(key, default=''):
    try:
        if control is None:
            return default
        v = control.setting(key)
        if v is None or v == '':
            return default
        return v
    except Exception:
        return default


def _is_true(value):
    return str(value).lower() == 'true'


def _addon_path(addon_id):
    """Resolve an installed addon's path or return ''. Safe outside Kodi."""
    if xbmcaddon is None:
        return ''
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        if xbmcvfs is not None and hasattr(xbmcvfs, 'translatePath'):
            path = xbmcvfs.translatePath(path)
        return path
    except Exception:
        return ''


def _load_external(candidates, label):
    """Try to import the external scraper module's `sources` callable.

    Returns a list of (provider_name, provider_module) tuples produced
    by the external scraper's own sources() function, or [] on failure.
    """
    import sys
    from importlib import import_module

    for addon_id in candidates:
        path = _addon_path(addon_id)
        if not path:
            continue
        lib_dir = os.path.join(path, 'lib')
        if lib_dir not in sys.path:
            sys.path.append(lib_dir)
        # The convention used by Umbrella/Fen-style external providers is
        # that the addon ships a top-level package whose name matches
        # the last segment of its addon id and exposes a `sources` callable.
        module_name = addon_id.split('.')[-1]
        try:
            mod = import_module(module_name)
            external_sources = getattr(mod, 'sources', None)
            if external_sources is None:
                log_utils.log(
                    '[thechains] %s: %s has no sources() entry' % (label, addon_id),
                    log_utils.LOGWARNING)
                continue
            try:
                src = external_sources()
            except TypeError:
                # Some implementations accept extra args
                src = external_sources()
            if src:
                log_utils.log(
                    '[thechains] %s: loaded %s providers from %s' %
                    (label, len(src), addon_id), log_utils.LOGINFO)
                return list(src)
        except Exception as e:
            log_utils.log(
                '[thechains] %s: failed to load %s (%s)' %
                (label, addon_id, e), log_utils.LOGWARNING)
            continue
    return []


def _internal_sources():
    sourceDict = []
    for i in __all__:
        for loader, module_name, is_pkg in pkgutil.walk_packages(
                [os.path.join(os.path.dirname(__file__), i)]):
            if is_pkg:
                continue
            try:
                module = loader.find_module(module_name).load_module(module_name)
                sourceDict.append((module_name, module.s0urce()))
            except Exception as e:
                log_utils.log('Could not load "%s": %s' % (module_name, e),
                              log_utils.LOGDEBUG)
    return sourceDict


def sources():
    """Return the active provider list.

    If the user has enabled CocoScrapers and/or Gears Scrapers in
    settings, return providers from those external modules and skip the
    internal scrapers entirely so the two sets do not interfere.
    """
    use_coco = _is_true(_setting('coco_scrapers.enabled', 'false'))
    use_gears = _is_true(_setting('gears_scrapers.enabled', 'false'))

    if not (use_coco or use_gears):
        return _internal_sources()

    sourceDict = []
    seen = set()

    if use_coco:
        for entry in _load_external(_COCO_CANDIDATES, 'coco'):
            try:
                name = entry[0]
            except Exception:
                continue
            if name in seen:
                continue
            seen.add(name)
            sourceDict.append(entry)

    if use_gears:
        for entry in _load_external(_GEARS_CANDIDATES, 'gears'):
            try:
                name = entry[0]
            except Exception:
                continue
            if name in seen:
                continue
            seen.add(name)
            sourceDict.append(entry)

    if not sourceDict:
        # External requested but none loaded -> notify and fall back to
        # internal so the user is not left with zero scrapers.
        try:
            if control is not None:
                control.notification(
                    title='The Chains',
                    message='External scrapers enabled but none could be loaded. '
                            'Using internal scrapers.')
        except Exception:
            pass
        return _internal_sources()

    log_utils.log(
        '[thechains] external scrapers active (coco=%s, gears=%s) – '
        'internal scrapers skipped' % (use_coco, use_gears),
        log_utils.LOGINFO)
    return sourceDict


def getAllHosters():
    def _sources(sourceFolder, appendList):
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        for i in sourceSubFolders:
            for loader, module_name, is_pkg in pkgutil.walk_packages(
                    [os.path.join(sourceFolderLocation, i)]):
                if is_pkg:
                    continue
                try:
                    mn = str(module_name).split('_')[0]
                except Exception:
                    mn = str(module_name)
                appendList.append(mn)

    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    appendList = []
    for item in sourceSubFolders:
        if item != 'modules':
            _sources(item, appendList)
    return list(set(appendList))
