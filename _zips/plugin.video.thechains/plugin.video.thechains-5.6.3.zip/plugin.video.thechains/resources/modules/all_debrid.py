# -*- coding: utf-8 -*-

import time
import xbmc
import logging

from resources.modules.client import get_html
from resources.modules import log


class AllDebrid:

    def __init__(self):

        from resources.modules import tools

        self.tools = tools

        self.agent_identifier = (
            self.tools.addonName.replace(' ', '_')
        )

        self.token = self.tools.getSetting(
            'alldebrid.token'
        )

        self.base_url = (
            'https://api.alldebrid.com/v4/'
        )

    def get_url(self, url, token_req=False):

        url = '{}{}'.format(self.base_url, url)

        if '?' not in url:
            url += '?agent={}'.format(
                self.agent_identifier
            )

        else:
            url += '&agent={}'.format(
                self.agent_identifier
            )

        if token_req and self.token:
            url += '&apikey={}'.format(
                self.token
            )

        try:

            response = get_html(url).json()

            return response

        except Exception as e:

            log.warning(
                'AllDebrid GET Error: %s' % str(e)
            )

            return None

    def post_url(
        self,
        url,
        post_data=None,
        token_req=False
    ):

        url = '{}{}'.format(self.base_url, url)

        if '?' not in url:
            url += '?agent={}'.format(
                self.agent_identifier
            )

        else:
            url += '&agent={}'.format(
                self.agent_identifier
            )

        if token_req and self.token:
            url += '&apikey={}'.format(
                self.token
            )

        try:

            response = get_html(
                url,
                data=post_data
            ).json()

            return response

        except Exception as e:

            log.warning(
                'AllDebrid POST Error: %s' % str(e)
            )

            return None

    def auth(self):

        try:

            pin_url = (
                '{}pin/get?agent={}'
            ).format(
                self.base_url,
                self.agent_identifier
            )

            response = get_html(
                pin_url
            ).json()

            if response.get('status') != 'success':

                xbmc.executebuiltin(
                    'Notification(%s,%s)' % (
                        self.tools.addonName,
                        'AllDebrid auth failed'
                    )
                )

                return

            resp = response.get('data', {})

            expiry = pin_ttl = int(
                resp.get('expires_in', 600)
            )

            auth_complete = False

            self.tools.copy2clip(
                resp.get('pin', '')
            )

            self.tools.progressDialog.create(
                '{} - {}'.format(
                    self.tools.addonName,
                    'AllDebrid Auth'
                )
            )

            self.tools.progressDialog.update(
                100,
                'Open this link in a browser: {}'.format(
                    self.tools.colorString(
                        resp.get('base_url', '')
                    )
                ) + '\n' +
                'Enter the code: {}'.format(
                    self.tools.colorString(
                        resp.get('pin', '')
                    )
                ) + '\n' +
                'This code has been copied to your clipboard'
            )

            time.sleep(8)

            while (
                not auth_complete and
                expiry > 0 and
                not self.tools.progressDialog.iscanceled()
            ):

                auth_complete, expiry = (
                    self.poll_auth(
                        resp.get(
                            'check_url',
                            ''
                        )
                    )
                )

                progress_percent = 100 - int(
                    (
                        float(
                            pin_ttl - expiry
                        ) / pin_ttl
                    ) * 100
                )

                self.tools.progressDialog.update(
                    progress_percent
                )

                time.sleep(2)

            try:
                self.tools.progressDialog.close()

            except:
                pass

            if auth_complete:

                self.store_user_info()

                xbmc.executebuiltin(
                    'Notification(%s,%s)' % (
                        self.tools.addonName,
                        'Authentication completed'
                    )
                )

            else:

                xbmc.executebuiltin(
                    'Notification(%s,%s)' % (
                        self.tools.addonName,
                        'Authentication failed'
                    )
                )

        except Exception as e:

            log.warning(
                'AllDebrid Auth Error: %s'
                % str(e)
            )

            try:
                self.tools.progressDialog.close()

            except:
                pass

    def poll_auth(self, poll_url):

        try:

            response = get_html(
                poll_url
            ).json()

            if response.get('status') != 'success':
                return False, 0

            resp = response.get('data', {})

            if resp.get('activated') is True:

                apikey = resp.get('apikey')

                if not apikey:
                    return False, 0

                self.tools.setSetting(
                    'alldebrid.token',
                    apikey
                )

                self.token = apikey

                return True, 0

            return (
                False,
                int(
                    resp.get(
                        'expires_in',
                        0
                    )
                )
            )

        except Exception as e:

            log.warning(
                'AllDebrid Poll Error: %s'
                % str(e)
            )

            return False, 0

    def store_user_info(self):

        try:

            user_information = self.get_url(
                'user',
                True
            )

            if not user_information:
                return

            if (
                user_information.get(
                    'status'
                ) != 'success'
            ):
                return

            username = (
                user_information.get(
                    'data',
                    {}
                ).get(
                    'user',
                    {}
                ).get(
                    'username',
                    ''
                )
            )

            self.tools.setSetting(
                'alldebrid.username',
                username
            )

        except Exception as e:

            log.warning(
                'AllDebrid User Info Error: %s'
                % str(e)
            )

    def check_hash(self, hash_list):

        all_mag = []

        for itt in hash_list:
            all_mag.append(itt)

        return self.get_url(
            'magnet/instant?magnets[]=' +
            '&magnets[]='.join(all_mag),
            token_req=True
        )

    def upload_magnet(self, hash):

        return self.get_url(
            'magnet/upload?magnet={}'.format(
                hash
            ),
            token_req=True
        )

    def update_relevant_hosters(self):

        return self.get_url('hosts')

    def get_hosters(self, hosters):

        import database

        host_list = database.get(
            self.update_relevant_hosters,
            1
        )

        if host_list is None:
            host_list = (
                self.update_relevant_hosters()
            )

        if host_list is not None:

            hosters['premium'][
                'all_debrid'
            ] = [
                (
                    i['domain'],
                    i['domain'].split('.')[0]
                )
                for i in host_list['hosts']
                if i['status']
            ]

            hosters['premium'][
                'all_debrid'
            ] += [
                (
                    host,
                    host.split('.')[0]
                )
                for i in host_list['hosts']
                if (
                    'altDomains' in i and
                    i['status']
                )
                for host in i['altDomains']
            ]

        else:

            hosters['premium'][
                'all_debrid'
            ] = []

    def resolve_hoster(self, url):

        url = self.tools.quote(url)

        resolve = self.get_url(
            'link/unlock?link={}'.format(
                url
            ),
            token_req=True
        )

        if (
            resolve and
            resolve.get('status') == 'success'
        ):

            return resolve['data']['link']

        return None

    def magnet_status(self, magnet_id):

        return self.get_url(
            'magnet/status?id={}'.format(
                magnet_id
            ),
            token_req=True
        )

    def delete_magnet(self, magnet_id):

        return self.get_url(
            'magnet/delete?id={}'.format(
                magnet_id
            ),
            token_req=True
        )
