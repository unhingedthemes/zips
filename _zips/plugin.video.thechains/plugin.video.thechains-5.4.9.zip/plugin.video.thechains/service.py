# -*- coding: utf-8 -*-
"""The Chains background service.

Every CHECK_INTERVAL seconds the service:

  1. Crawls every chain URL referenced by the addon's main menu and
     records any newly-added media (movies / TV shows / sub-lists) in
     the local What's New auto feed.
  2. Fires a Kodi toast as soon as new content is detected, telling the
     user *what* was added and *where* to find it.

The service also installs a Ctrl+D global keymap so the debug bundle
can be triggered from anywhere inside Kodi.
"""
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ICON = os.path.join(ADDON_PATH, 'icon.png')

CHECK_INTERVAL = 30 * 60  # 30 minutes
INITIAL_DELAY = 20         # seconds before the very first scan
LOG_TAG = '[%s.service]' % ADDON_ID

KEYMAP_TARGET = xbmcvfs.translatePath(
    'special://userdata/keymaps/thechains_debug.xml')

KEYMAP_XML = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Installed by plugin.video.thechains. Maps Ctrl+D to the debug bundle. -->
<keymap>
  <global>
    <keyboard>
      <d mod="ctrl">RunPlugin(plugin://plugin.video.thechains/?mode=251&amp;url=www)</d>
    </keyboard>
  </global>
</keymap>
"""


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('%s %s' % (LOG_TAG, msg), level)
    except Exception:
        pass


def install_keymap():
    """Drop the Ctrl+D keymap into the user's keymaps folder once."""
    try:
        d = os.path.dirname(KEYMAP_TARGET)
        if d and not os.path.exists(d):
            os.makedirs(d)
        if os.path.exists(KEYMAP_TARGET):
            with open(KEYMAP_TARGET, 'r', encoding='utf-8') as f:
                if f.read().strip() == KEYMAP_XML.strip():
                    return
        with open(KEYMAP_TARGET, 'w', encoding='utf-8') as f:
            f.write(KEYMAP_XML)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        log('keymap installed at %s' % KEYMAP_TARGET)
    except Exception as e:
        log('install_keymap error: %s' % e, xbmc.LOGERROR)


def _notify(title, message, icon, time_ms=6000):
    try:
        xbmcgui.Dialog().notification(title, message, icon, time_ms, False)
    except Exception as e:
        log('notify error: %s' % e, xbmc.LOGERROR)


def run_check():
    try:
        from resources.modules import whatsnew
    except Exception as e:
        log('whatsnew import failed: %s' % e, xbmc.LOGERROR)
        return

    try:
        new_entries = whatsnew.detect_new_chain_items() or []
    except Exception as e:
        log('detect_new_chain_items: %s' % e, xbmc.LOGERROR)
        return

    if not new_entries:
        return

    log('detected %d new chain entr%s' %
        (len(new_entries), 'y' if len(new_entries) == 1 else 'ies'))

    # Mark every fresh entry as seen so we don't re-notify next pass
    state = whatsnew.load_seen()
    seen_ids = set(state.get('ids', []))
    for it in new_entries:
        eid = it.get('id') or it.get('title')
        if eid:
            seen_ids.add(eid)
    state['ids'] = sorted(seen_ids)
    state['bootstrapped'] = True
    whatsnew.save_seen(state)

    # Toast immediately - one per entry up to 3, then a summary
    notify_icon = ICON if os.path.exists(ICON) else xbmcgui.NOTIFICATION_INFO
    fresh = new_entries[:3]
    for it in fresh:
        title = it.get('title', 'New media')
        parent = it.get('parent', '')
        msg = ('Added to %s' % parent) if parent else 'New in The Chains'
        _notify("%s - What's New" % ADDON_NAME, '%s - %s' % (title, msg),
                notify_icon, 6000)
    if len(new_entries) > len(fresh):
        more = len(new_entries) - len(fresh)
        _notify("%s - What's New" % ADDON_NAME,
                '+%d more new item%s' % (more, '' if more == 1 else 's'),
                notify_icon, 5000)


def main():
    log('service starting (check every %ds)' % CHECK_INTERVAL)
    install_keymap()
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(INITIAL_DELAY):
        return
    while not monitor.abortRequested():
        try:
            run_check()
        except Exception as e:
            log('check error: %s' % e, xbmc.LOGERROR)
        if monitor.waitForAbort(CHECK_INTERVAL):
            break
    log('service stopping')


if __name__ == '__main__':
    main()
