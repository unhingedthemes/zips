# -*- coding: utf-8 -*-
"""The Chains - What's New helper.

Tracks newly-added media (movies / TV shows / sub-lists) inside the
chain URLs that the addon's main menu points at (the .txt files served
from thechains24.com). Whenever the author publishes a new entry into
one of those chain feeds we detect it within 30 minutes, write it to a
local feed, fire a toast notification, and surface it in the What's New
listing with poster + fanart. Clicking the entry opens / plays the
content directly.
"""
import json
import os
import re
import time
import hashlib

import xbmc
import xbmcaddon
import xbmcvfs

try:
    import urllib.request as _urlreq
except Exception:  # pragma: no cover
    import urllib2 as _urlreq


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

AUTO_FILE = os.path.join(PROFILE_DIR, 'whatsnew_auto.json')
SEEN_FILE = os.path.join(PROFILE_DIR, 'whatsnew_seen.json')
CHAIN_SNAPSHOT_FILE = os.path.join(PROFILE_DIR, 'chain_snapshot.json')

# Maximum number of auto entries we keep in the local feed.
MAX_AUTO_ENTRIES = 200
# How deep to crawl the chain (root .txt -> sub .txt). 1 = only root list.
CRAWL_DEPTH = 1
HTTP_TIMEOUT = 10

LOG_TAG = '[%s.whatsnew]' % ADDON_ID


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('%s %s' % (LOG_TAG, msg), level)
    except Exception:
        pass


def _ensure_dir(path):
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        try:
            os.makedirs(d)
        except Exception:
            pass


def load_json(path, default):
    try:
        if not os.path.exists(path):
            return default
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log('load_json %s: %s' % (path, e), xbmc.LOGERROR)
        return default


def save_json(path, data):
    try:
        _ensure_dir(path)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        log('save_json %s: %s' % (path, e), xbmc.LOGERROR)


def _now_str():
    return time.strftime('%Y-%m-%d %H:%M')


def _http_get(url, timeout=HTTP_TIMEOUT):
    req = _urlreq.Request(url, headers={
        'User-Agent': 'TheChains/%s' % ADDON.getAddonInfo('version')
    })
    with _urlreq.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')


def _strip_tags(s):
    if not s:
        return ''
    return re.sub(r'\[/?[^\]]+\]', '', s).strip()


# ------------------------------------------------------------------
#  Chain root discovery (parse menus.py)
# ------------------------------------------------------------------
_MENU_LINE_RE = re.compile(
    r"addDir3\(\s*['\"]([^'\"]+)['\"]\s*,"
    r"\s*['\"](https?://[^'\"]+\.txt)['\"]\s*,"
    r"\s*189\s*,"
    r"\s*['\"]([^'\"]*)['\"]\s*,"
    r"\s*['\"]([^'\"]*)['\"]"
)


def _chain_roots():
    """Return [{'name','url','icon','fanart'}, ...] for every chain in main_menu."""
    roots = []
    try:
        menus_path = os.path.join(ADDON_PATH, 'resources', 'menus.py')
        if not os.path.exists(menus_path):
            return roots
        with open(menus_path, 'r', encoding='utf-8') as f:
            src = f.read()
        m = re.search(r'def\s+main_menu\s*\(.*?\):(.*?)\n\s*def\s+', src, re.S)
        body = m.group(1) if m else src
        seen = set()
        for label, url, icon, fanart in _MENU_LINE_RE.findall(body):
            name = _strip_tags(label) or url
            key = (name, url)
            if key in seen:
                continue
            seen.add(key)
            roots.append({
                'name': name,
                'url': url,
                'icon': icon,
                'fanart': fanart,
            })
    except Exception as e:
        log('chain_roots: %s' % e, xbmc.LOGERROR)
    return roots


# ------------------------------------------------------------------
#  Chain text parser
# ------------------------------------------------------------------
_DIR_BLOCK_RE = re.compile(r'<dir>(.*?)</dir>', re.S | re.I)


def _tag(block, tag):
    m = re.search(r'<%s>\s*(.*?)\s*</%s>' % (tag, tag), block, re.S | re.I)
    return m.group(1).strip() if m else ''


def _parse_chain_text(text, parent):
    """Parse a chain .txt body into a list of entry dicts."""
    items = []
    if not text:
        return items
    for block in _DIR_BLOCK_RE.findall(text):
        title = _strip_tags(_tag(block, 'title'))
        if not title:
            continue
        link = _tag(block, 'link') or _tag(block, 'trakt') or _tag(block, 'tmdb') or ''
        thumb = _tag(block, 'thumbnail') or parent.get('icon', '')
        fanart = _tag(block, 'fanart') or parent.get('fanart', '')
        items.append({
            'title': title,
            'link': link,
            'thumbnail': thumb,
            'fanart': fanart,
            'parent': parent.get('name', ''),
            'parent_url': parent.get('url', ''),
            'kind': ('link' if _tag(block, 'link')
                     else 'trakt' if _tag(block, 'trakt')
                     else 'tmdb' if _tag(block, 'tmdb')
                     else 'unknown'),
        })
    return items


def _entry_id(parent_url, title, link):
    raw = '%s|%s|%s' % (parent_url or '', title or '', link or '')
    return 'chain-' + hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]


# ------------------------------------------------------------------
#  Crawler + diff
# ------------------------------------------------------------------
def _crawl_chains(depth=CRAWL_DEPTH):
    """Walk every chain root + (optionally) its first-level sub-lists.

    Returns a flat list of entries (each already enriched with parent
    info + a stable id).
    """
    out = []
    seen_ids = set()
    roots = _chain_roots()
    for root in roots:
        try:
            text = _http_get(root['url'])
        except Exception as e:
            log('crawl %s: %s' % (root['url'], e), xbmc.LOGINFO)
            continue
        items = _parse_chain_text(text, root)
        for it in items:
            it['id'] = _entry_id(root['url'], it['title'], it['link'])
            if it['id'] not in seen_ids:
                seen_ids.add(it['id'])
                out.append(it)
        if depth <= 0:
            continue
        # Walk one level deeper into sub-lists that point at another .txt
        for it in list(items):
            sub_link = it.get('link', '')
            if not sub_link.lower().endswith('.txt'):
                continue
            try:
                sub_text = _http_get(sub_link)
            except Exception as e:
                log('crawl sub %s: %s' % (sub_link, e), xbmc.LOGINFO)
                continue
            sub_parent = {
                'name': '%s / %s' % (root['name'], it['title']),
                'url': sub_link,
                'icon': it.get('thumbnail') or root.get('icon', ''),
                'fanart': it.get('fanart') or root.get('fanart', ''),
            }
            for sub in _parse_chain_text(sub_text, sub_parent):
                sub['id'] = _entry_id(sub_link, sub['title'], sub['link'])
                if sub['id'] not in seen_ids:
                    seen_ids.add(sub['id'])
                    out.append(sub)
    return out


def detect_new_chain_items():
    """Compare the crawl against the saved snapshot and persist new entries.

    On the very first run we just record the snapshot so the user is not
    flooded with a notification for every existing item. Returns the list
    of brand-new entries detected on this pass.
    """
    new_entries = []
    current = _crawl_chains()
    if not current:
        return new_entries
    snap = load_json(CHAIN_SNAPSHOT_FILE, None)
    keys_now = {it['id'] for it in current}

    if snap is None:
        save_json(CHAIN_SNAPSHOT_FILE, {
            'ids': sorted(keys_now),
            'updated': _now_str(),
        })
        return new_entries

    keys_old = set(snap.get('ids', []))
    added = [it for it in current if it['id'] not in keys_old]
    if not added:
        # Always refresh updated stamp so we know the scan ran
        snap['updated'] = _now_str()
        save_json(CHAIN_SNAPSHOT_FILE, snap)
        return new_entries

    auto = load_json(AUTO_FILE, {'entries': []})
    auto.setdefault('entries', [])
    existing_ids = {e.get('id') for e in auto['entries']}
    now = _now_str()
    for it in added:
        if it['id'] in existing_ids:
            continue
        entry = {
            'id': it['id'],
            'title': it['title'],
            'link': it['link'],
            'kind': it.get('kind', 'unknown'),
            'thumbnail': it.get('thumbnail', ''),
            'fanart': it.get('fanart', ''),
            'parent': it.get('parent', ''),
            'parent_url': it.get('parent_url', ''),
            'added': now,
        }
        auto['entries'].insert(0, entry)
        new_entries.append(entry)
    # Trim to MAX_AUTO_ENTRIES so the file does not grow forever
    auto['entries'] = auto['entries'][:MAX_AUTO_ENTRIES]
    save_json(AUTO_FILE, auto)
    save_json(CHAIN_SNAPSHOT_FILE, {
        'ids': sorted(keys_now),
        'updated': now,
    })
    return new_entries


# ------------------------------------------------------------------
#  Aggregated entries (newest first) - chain-only
# ------------------------------------------------------------------
def all_entries(include_remote=False):  # include_remote kept for backwards compat
    auto = load_json(AUTO_FILE, {}).get('entries', []) or []
    merged = []
    seen_ids = set()
    for it in auto:
        if not isinstance(it, dict):
            continue
        eid = it.get('id') or it.get('title') or ''
        if not eid or eid in seen_ids:
            continue
        seen_ids.add(eid)
        merged.append(it)
    try:
        merged.sort(key=lambda x: x.get('added', ''), reverse=True)
    except Exception:
        pass
    return merged


# ------------------------------------------------------------------
#  Backwards-compat shims (used by service.py / mode 250)
# ------------------------------------------------------------------
def detect_new_menu_items():  # legacy alias
    return detect_new_chain_items()


def fetch_remote(timeout=10):
    """Remote feed disabled - chain crawler is the source of truth."""
    return {}


# ------------------------------------------------------------------
#  Seen tracking
# ------------------------------------------------------------------
def load_seen():
    state = load_json(SEEN_FILE, {})
    if not isinstance(state, dict):
        state = {}
    state.setdefault('ids', [])
    state.setdefault('bootstrapped', False)
    return state


def save_seen(state):
    state['last_check'] = time.time()
    save_json(SEEN_FILE, state)


def diff_unseen(entries):
    """Return entries from ``entries`` whose id was never seen before."""
    state = load_seen()
    seen_ids = set(state.get('ids', []))
    fresh = [e for e in entries
             if (e.get('id') or e.get('title')) and
                (e.get('id') or e.get('title')) not in seen_ids]
    return fresh, state
