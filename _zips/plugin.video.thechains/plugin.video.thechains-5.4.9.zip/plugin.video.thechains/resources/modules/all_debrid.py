# -*- coding: utf-8 -*-

import time, xbmc, logging

from resources.modules.client import get_html
from resources.modules import log


class AllDebrid:

    def __init__(self):
        from resources.modules import tools
        self.tools = tools
        self.agent_identifier = self.tools.addonName
        self.token = self.tools.getSetting('alldebrid.token')
        # v4 base for most calls; v4.1 used for pin/get and magnet/status (per AllDebrid migration 2024/2025)
        self.base_url = 'https://api.alldebrid.com/v4/'
        self.base_url_v41 = 'https://api.alldebrid.com/v4.1/'
        if self.token == '':
            self.auth()

    # ---------------------------------------------------------------- helpers

    def _request(self, endpoint, token_req=False, base=None, data=None):
        """Build a URL against the chosen base, send GET (or POST when data given), return parsed JSON or None."""
        if token_req and self.token == '':
            return None
        b = base or self.base_url
        url = '{}{}'.format(b, endpoint)
        sep = '&' if '?' in url else '?'
        url += '{}agent={}'.format(sep, self.agent_identifier)
        if token_req:
            url += '&apikey={}'.format(self.token)
        try:
            if data is not None:
                return get_html(url, data=data).json()
            return get_html(url).json()
        except Exception:
            try:
                log.warning('AllDebrid request failed for: %s' % endpoint)
            except Exception:
                pass
            return None

    def get_url(self, url, token_req=False):
        return self._request(url, token_req=token_req)

    def post_url(self, url, post_data=None, token_req=False):
        return self._request(url, token_req=token_req, data=post_data or {})

    # ---------------------------------------------------------------- auth

    def auth(self):
        # /v4.1/pin/get is the current endpoint (v4 deprecated). check_url is no longer returned.
        pin_resp = self._request('pin/get', base=self.base_url_v41)
        if not pin_resp or pin_resp.get('status') != 'success':
            xbmc.executebuiltin(u'Notification(%s,%s)' % (self.tools.addonName, 'AllDebrid pin request failed'))
            return
        resp = pin_resp['data']
        expiry = pin_ttl = int(resp['expires_in'])
        check_token = resp.get('check', '')
        pin_code = resp.get('pin', '')

        auth_complete = False
        try:
            self.tools.copy2clip(pin_code)
        except Exception:
            pass

        self.tools.progressDialog.create('{} - {}'.format(self.tools.addonName, 'AllDebrid Auth'))
        self.tools.progressDialog.update(
            100,
            'Open this link in a browser: {}'.format(self.tools.colorString(resp.get('user_url', resp.get('base_url', '')))) + '\n' +
            'Enter the code: {}'.format(self.tools.colorString(pin_code)) + '\n' +
            'This code has been copied to your clipboard'
        )

        # Servers need a moment before the pin can be polled
        time.sleep(5)

        while not auth_complete and expiry > 0 and not self.tools.progressDialog.iscanceled():
            auth_complete, expiry = self.poll_auth(pin_code, check_token)
            progress_percent = 100 - int((float(pin_ttl - expiry) / pin_ttl) * 100)
            self.tools.progressDialog.update(progress_percent)
            time.sleep(1)

        try:
            self.tools.progressDialog.close()
        except Exception:
            pass

        if auth_complete:
            self.store_user_info()
            xbmc.executebuiltin(u'Notification(%s,%s)' % (self.tools.addonName, 'Authentication is completed'))

    def poll_auth(self, pin, check):
        # /v4/pin/check is a POST with pin & check params
        resp = self._request('pin/check', data={'pin': pin, 'check': check})
        if not resp or 'data' not in resp:
            return False, 0
        data = resp['data']
        if data.get('activated'):
            self.tools.setSetting('alldebrid.token', data['apikey'])
            self.token = data['apikey']
            return True, 0
        return False, int(data.get('expires_in', 0))

    def store_user_info(self):
        user_information = self.get_url('user', True)
        try:
            self.tools.setSetting('alldebrid.username', user_information['data']['user']['username'])
        except Exception:
            pass

    # ---------------------------------------------------------------- magnet/instant (removed by AllDebrid)

    def check_hash(self, hash_list):
        """
        AllDebrid removed the /magnet/instant endpoint. There is no longer a way to query
        cached availability without uploading. We mimic the old "all not-cached" reply so
        callers don't crash; they then fall back to the upload + status flow.
        """
        all_mag = list(hash_list) if hash_list else []
        return {
            'status': 'success',
            'data': {
                'magnets': [{'hash': h, 'magnet': h, 'instant': False} for h in all_mag]
            }
        }

    # ---------------------------------------------------------------- magnet flow

    def upload_magnet(self, hash):
        return self.get_url('magnet/upload?magnet={}'.format(hash), token_req=True)

    def magnet_status(self, magnet_id):
        # v4.1/magnet/status is the supported endpoint. v4 was deprecated 2024-10-16.
        return self._request('magnet/status?id={}'.format(magnet_id), token_req=True, base=self.base_url_v41)

    def magnet_files(self, magnet_id):
        # New dedicated endpoint that holds links/files info (formerly bundled in magnet/status).
        return self._request('magnet/files?id[]={}'.format(magnet_id), token_req=True)

    def delete_magnet(self, magnet_id):
        return self.get_url('magnet/delete?id={}'.format(magnet_id), token_req=True)

    def update_relevant_hosters(self):
        return self.get_url('hosts')

    def get_hosters(self, hosters):
        import database
        host_list = database.get(self.update_relevant_hosters, 1)
        if host_list is None:
            host_list = self.update_relevant_hosters()
        try:
            data = host_list.get('data', host_list) if isinstance(host_list, dict) else {}
            hosts_obj = data.get('hosts', {}) if isinstance(data, dict) else {}
            premium = []
            # hosts is a dict keyed by host name; each host has a 'domains' array
            iterable = hosts_obj.values() if isinstance(hosts_obj, dict) else hosts_obj
            for h_obj in iterable:
                if not isinstance(h_obj, dict):
                    continue
                if h_obj.get('status') is False:
                    continue
                for dom in h_obj.get('domains', []) or []:
                    premium.append((dom, dom.split('.')[0]))
            hosters['premium']['all_debrid'] = premium
        except Exception:
            import traceback
            traceback.print_exc()
            hosters['premium']['all_debrid'] = []

    # ---------------------------------------------------------------- link unlock

    def resolve_hoster(self, url):
        url = self.tools.quote(url)
        resolve = self.get_url('link/unlock?link={}'.format(url), token_req=True)
        if not resolve or not isinstance(resolve, dict):
            return None
        if resolve.get('status') == 'success':
            try:
                return resolve['data']['link']
            except Exception:
                return None
        try:
            err = resolve.get('error', {}).get('message', 'Unknown AllDebrid error')
            log.warning('AllDebrid unlock error: %s' % err)
        except Exception:
            pass
        return None

    # ---------------------------------------------------------------- helpers used by movie/tv resolve

    def _wait_until_ready(self, magnet_id, timeout=20):
        """Poll magnet/status until statusCode==4 (Ready) or an error/timeout."""
        deadline = time.time() + timeout
        last_code = None
        while time.time() < deadline:
            resp = self.magnet_status(magnet_id)
            try:
                m = resp['data']['magnets']
                if isinstance(m, list):
                    if not m:
                        return False
                    m = m[0]
                code = m.get('statusCode')
                last_code = code
                if code == 4:
                    return True
                if code is not None and code >= 5:
                    log.warning('AllDebrid magnet error statusCode=%s' % code)
                    return False
            except Exception:
                pass
            time.sleep(1)
        log.warning('AllDebrid magnet not Ready (last statusCode=%s)' % last_code)
        return False

    def _extract_links(self, files_resp):
        """Pull the flat [{link, filename}, ...] list out of a /magnet/files response."""
        out = []
        try:
            magnets_arr = files_resp['data']['magnets']
            if isinstance(magnets_arr, list):
                if not magnets_arr:
                    return out
                obj = magnets_arr[0]
            elif isinstance(magnets_arr, dict):
                obj = magnets_arr
            else:
                return out
            links = obj.get('links') or []
            for it in links:
                if isinstance(it, dict) and it.get('link') and it.get('filename'):
                    out.append({'link': it['link'], 'filename': it['filename']})
        except Exception:
            pass
        return out

    # ---------------------------------------------------------------- public resolvers

    def movie_magnet_to_stream(self, magnet, season, episode, tv_movie):
        selectedFile = None

        upload = self.upload_magnet(magnet)
        if not upload or upload.get('status') != 'success':
            try:
                err_msg = upload['error']['message']
            except Exception:
                err_msg = 'AllDebrid upload failed'
            xbmc.executebuiltin(u'Notification(%s,%s)' % (self.tools.addonName + ' Error', err_msg))
            return None

        try:
            magnet_id = upload['data']['magnets'][0]['id']
        except Exception:
            return None

        if not self._wait_until_ready(magnet_id, timeout=20):
            try:
                self.delete_magnet(magnet_id)
            except Exception:
                pass
            return None

        files_resp = self.magnet_files(magnet_id)
        folder_details = self._extract_links(files_resp)

        for items in folder_details:
            test_name = items['filename'].lower()
            if not (test_name.endswith('.mkv') or test_name.endswith('.avi')
                    or test_name.endswith('.mp4') or test_name.endswith('.m4v')
                    or test_name.endswith('.mov') or 'mkv' in test_name
                    or 'avi' in test_name or 'mp4' in test_name):
                continue

            if tv_movie == 'movie':
                selectedFile = items['link']
                break

            ep_patterns = (
                's%se%s.' % (season, str(int(episode))),
                's%se%s ' % (season, episode),
                's%se%s.' % (season, episode),
                'ep ' + str(episode),
                str(int(season)) + str(episode),
                str(int(season)) + 'x' + str(episode),
            )
            if any(p in test_name for p in ep_patterns):
                selectedFile = items['link']
                break

        try:
            self.delete_magnet(magnet_id)
        except Exception:
            pass

        if not selectedFile:
            return None
        return self.resolve_hoster(selectedFile)

    def resolve_magnet(self, magnet, args, torrent, pack_select=False):
        import source_utils
        if 'showInfo' not in args:
            return self.movie_magnet_to_stream(magnet, args, '', 'movie')

        upload = self.upload_magnet(magnet)
        if not upload or upload.get('status') != 'success':
            return None
        try:
            magnet_id = upload['data']['magnets'][0]['id']
        except Exception:
            return None

        episodeStrings, seasonStrings = source_utils.torrentCacheStrings(args)

        try:
            if not self._wait_until_ready(magnet_id, timeout=20):
                self.delete_magnet(magnet_id)
                return None

            files_resp = self.magnet_files(magnet_id)
            folder_details = self._extract_links(files_resp)

            if 'extra' not in args['info']['title'] and 'extra' not in args['showInfo']['info']['tvshowtitle'] \
                    and int(args['info']['season']) != 0:
                folder_details = [i for i in folder_details if
                                  'extra' not in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower())]

            if 'special' not in args['info']['title'] and 'special' not in args['showInfo']['info']['tvshowtitle'] \
                    and int(args['info']['season']) != 0:
                folder_details = [i for i in folder_details if
                                  'special' not in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower())]

            streamLink = self.check_episode_string(folder_details, episodeStrings)
            self.delete_magnet(magnet_id)

            if streamLink is None:
                return None
            return self.resolve_hoster(streamLink)
        except Exception:
            import traceback
            traceback.print_exc()
            try:
                self.delete_magnet(magnet_id)
            except Exception:
                pass
            return None

    def check_episode_string(self, folder_details, episodeStrings):
        import source_utils
        for i in folder_details:
            for epstring in episodeStrings:
                if epstring in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower()):
                    if any(i['filename'].endswith(ext) for ext in source_utils.COMMON_VIDEO_EXTENSIONS):
                        return i['link']
        return None
