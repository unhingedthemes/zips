# -*- coding: utf-8 -*-
'''
********************************************************cm*
* Torrentio Scraper
*
* @file torio.py
* @author CM
* @date 2025-07-04
* @copyright (c) 2025, CM
*
********************************************************cm*
'''

import re
from resources.modules import log
from resources.modules.client import get_html
from resources.modules import cache
from resources.modules.general import Addon, get_imdb


#global global_var, stop_all #global - these are already global!


global_var=[]
stop_all=0



def get_links(tv_movie, original_title, season_n, episode_n, season, episode, show_original_year, id):
    global global_var,stop_all

    base_link = "https://torrentio.strem.fun"
    movie_search_link = '/stream/movie/%s.json'
    tv_search_link = '/stream/series/%s:%s:%s.json'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    }

    item_info = re.compile(r'👤.*')


    all_links=[]
    imdb_id=cache.get(get_imdb, 999,tv_movie,id,table='pages')

    if tv_movie == 'movie':
        # Search for movies
        url = base_link + movie_search_link % imdb_id
    else:
        # search for TV shows
        url = base_link + tv_search_link % (imdb_id, season, episode)


    try:
        result=get_html(url,headers=headers,timeout=10).json()

        files = result.get('streams')
        if files is None:
            return all_links

        for file in files:
            if stop_all==1:
                break
            infohash = file['infoHash']
            file_title = file['title'].split('\n')
            file_info = [x for x in file_title if item_info.match(x)][0]
            title= file_title[0]

            name = file_title[0]

            if str(title) not in str(name):
                continue

            if '[RD+]' in file['name']:
                title="[I][Cached][/I] "+ file_title

            regex = '💾(.+?)⚙️'
            stringsize=re.compile(regex).findall(file_title[1])

            o_size = 0.0
            if len(stringsize):
                try:
                    o_size = float(stringsize[0].replace('GB','').replace('MB','').replace(",",'').strip())
                    if 'MB' in stringsize[0]:
                        o_size= o_size/1000
                except ValueError as e:
                    log.warning(f'[CM DEBUG @ 116 in torio.py]Exception raised while parsing size: {e}')
                    o_size = 0.0

            link = f'magnet:?xt=urn:btih:{infohash}&dn={name}'

            if '4k' in title:
                res='2160'
            elif '2160' in title:
                res='2160'
            elif '1080' in title:
                    res='1080'
            elif '720' in title:
                res='720'
            elif '480' in title:
                res='480'
            elif '360' in title:
                res='360'
            else:
                res='HD'
            max_size=int(Addon.getSetting("size_limit"))


            if (o_size) < max_size:
                all_links.append((title, link, str(o_size), res))

    except Exception as e:
        import traceback
        failure = traceback.format_exc()
        log.warning(f'[CM Debug @ 116 in torio.py]Traceback:: {failure}')
        log.warning(f'[CM Debug @ 116 in torio.py]Exception raised. Error = {e}')
        pass

    global_var= all_links
    return global_var