# -*- coding: utf-8 -*-

import time, xbmc

from resources.modules.client import get_html
from resources.modules import log


class AllDebrid:

    def __init__(self):
        from resources.modules import tools
        self.tools = tools
        self.agent_identifier = self.tools.addonName
        self.token = self.tools.getSetting('alldebrid.token')
        # v4 base for most calls; v4.1 used for pin/get and magnet/status (per AllDebrid 2024/2025 migration)
        self.base_url = 'https://api.alldebrid.com/v4/'
        self.base_url_v41 = 'https://api.alldebrid.com/v4.1/'
        if self.token == '':
            self.auth()

    # ---------------------------------------------------------------- helpers

    def _request(self, endpoint, token_req=False, base=None, data=None):
        """Build a URL against the chosen base, send GET (or POST when data given), return parsed JSON or None.
        Uses Authorization: Bearer header for auth (recommended by AllDebrid).
        Also keeps apikey query param as a fallback for older client behaviour.
        """
        if token_req and self.token == '':
            return None
        b = base or self.base_url
        url = '{}{}'.format(b, endpoint)
        sep = '&' if '?' in url else '?'
        url += '{}agent={}'.format(sep, self.agent_identifier)
        if token_req:
            url += '&apikey={}'.format(self.token)
        headers = {}
        if token_req:
            headers['Authorization'] = 'Bearer {}'.format(self.token)
        try:
            if data is not None:
                if headers:
                    return get_html(url, data=data, headers=headers, timeout=20).json()
                return get_html(url, data=data, timeout=20).json()
            if headers:
                return get_html(url, headers=headers, timeout=20).json()
            return get_html(url, timeout=20).json()
        except Exception:
            try:
                log.warning('AllDebrid request failed for: %s' % endpoint)
            except Exception:
                pass
            return None

    def get_url(self, url, token_req=False):
        return self._request(url, token_req=token_req)

    def post_url(self, url, post_data=None, token_req=False):
        return self._request(url, token_req=token_req, data=post_data or {})

    # ---------------------------------------------------------------- auth

    def auth(self):
        # /v4.1/pin/get is the current endpoint (v4 deprecated). check_url is no longer returned.
        pin_resp = self._request('pin/get', base=self.base_url_v41)
        if not pin_resp or pin_resp.get('status') != 'success':
            xbmc.executebuiltin(u'Notification(%s,%s)' % (self.tools.addonName, 'AllDebrid pin request failed'))
            return
        resp = pin_resp['data']
        expiry = pin_ttl = int(resp['expires_in'])
        check_token = resp.get('check', '')
        pin_code = resp.get('pin', '')

        auth_complete = False
        try:
            self.tools.copy2clip(pin_code)
        except Exception:
            pass

        self.tools.progressDialog.create('{} - {}'.format(self.tools.addonName, 'AllDebrid Auth'))
        self.tools.progressDialog.update(
            100,
            'Open this link in a browser: {}'.format(self.tools.colorString(resp.get('user_url', resp.get('base_url', '')))) + '\n' +
            'Enter the code: {}'.format(self.tools.colorString(pin_code)) + '\n' +
            'This code has been copied to your clipboard'
        )

        # Servers need a moment before the pin can be polled
        time.sleep(5)

        while not auth_complete and expiry > 0 and not self.tools.progressDialog.iscanceled():
            auth_complete, expiry = self.poll_auth(pin_code, check_token)
            progress_percent = 100 - int((float(pin_ttl - expiry) / pin_ttl) * 100)
            self.tools.progressDialog.update(progress_percent)
            time.sleep(1)

        try:
            self.tools.progressDialog.close()
        except Exception:
            pass

        if auth_complete:
            self.store_user_info()
            xbmc.executebuiltin(u'Notification(%s,%s)' % (self.tools.addonName, 'Authentication is completed'))

    def poll_auth(self, pin, check):
        # /v4/pin/check is a POST with pin & check params
        resp = self._request('pin/check', data={'pin': pin, 'check': check})
        if not resp or 'data' not in resp:
            return False, 0
        data = resp['data']
        if data.get('activated'):
            self.tools.setSetting('alldebrid.token', data['apikey'])
            self.token = data['apikey']
            return True, 0
        return False, int(data.get('expires_in', 0))

    def store_user_info(self):
        user_information = self.get_url('user', True)
        try:
            self.tools.setSetting('alldebrid.username', user_information['data']['user']['username'])
        except Exception:
            pass

    # ---------------------------------------------------------------- cache check (upload+ready workaround)

    def check_hash(self, hash_list):
        """
        AllDebrid removed /magnet/instant. Modern workaround: upload all hashes via magnet/upload
        and inspect the per-magnet `ready` flag. We then immediately delete the uploaded magnets
        that aren't cached so the user's account isn't polluted with junk.

        Returns the legacy-shaped response so existing callers keep working:
          {'status':'success','data':{'magnets':[{'hash':h,'magnet':h,'instant':bool,'id':id_or_None}, ...]}}
        """
        try:
            hashes = [h for h in (hash_list or []) if h]
            if not hashes:
                return {'status': 'success', 'data': {'magnets': []}}

            out = {h: {'hash': h, 'magnet': h, 'instant': False, 'id': None} for h in hashes}

            # Chunk to keep URLs sensible (AD accepts repeated magnets[] params).
            chunk_size = 30
            to_delete = []
            for start in range(0, len(hashes), chunk_size):
                chunk = hashes[start:start + chunk_size]
                qs = '&'.join(['magnets[]={}'.format(h) for h in chunk])
                resp = self._request('magnet/upload?{}'.format(qs), token_req=True)
                if not resp or resp.get('status') != 'success':
                    continue
                try:
                    mags = resp['data']['magnets'] or []
                except Exception:
                    mags = []
                for m in mags:
                    if not isinstance(m, dict):
                        continue
                    h = (m.get('hash') or '').lower()
                    if not h:
                        continue
                    # AD sometimes returns hash uppercase; normalise back to whatever the caller used.
                    matched_key = None
                    for original in chunk:
                        if original.lower() == h:
                            matched_key = original
                            break
                    if matched_key is None:
                        continue
                    is_ready = bool(m.get('ready'))
                    mid = m.get('id')
                    out[matched_key]['instant'] = is_ready
                    out[matched_key]['id'] = mid
                    # We always delete from the user's account afterwards so this acts as a probe
                    # only. Cached ones can be re-uploaded instantly when the user picks them.
                    if mid:
                        to_delete.append(mid)

            for mid in to_delete:
                try:
                    self.delete_magnet(mid)
                except Exception:
                    pass

            return {
                'status': 'success',
                'data': {'magnets': [out[h] for h in hashes]}
            }
        except Exception:
            return {
                'status': 'success',
                'data': {'magnets': [{'hash': h, 'magnet': h, 'instant': False, 'id': None} for h in (hash_list or [])]}
            }

    # ---------------------------------------------------------------- magnet flow

    def upload_magnet(self, hash):
        # AllDebrid expects magnets[] (array). Singular `magnet=` is not accepted.
        return self.get_url('magnet/upload?magnets[]={}'.format(hash), token_req=True)

    def magnet_status(self, magnet_id):
        # v4.1/magnet/status is the supported endpoint. v4 was deprecated 2024-10-16.
        return self._request('magnet/status?id={}'.format(magnet_id), token_req=True, base=self.base_url_v41)

    def magnet_files(self, magnet_id):
        # New dedicated endpoint that holds links/files info (formerly bundled in magnet/status).
        return self._request('magnet/files?id[]={}'.format(magnet_id), token_req=True)

    def delete_magnet(self, magnet_id):
        return self.get_url('magnet/delete?id={}'.format(magnet_id), token_req=True)

    def update_relevant_hosters(self):
        return self.get_url('hosts')

    def get_hosters(self, hosters):
        from resources.modules import database
        host_list = database.get(self.update_relevant_hosters, 1)
        if host_list is None:
            host_list = self.update_relevant_hosters()
        try:
            data = host_list.get('data', host_list) if isinstance(host_list, dict) else {}
            hosts_obj = data.get('hosts', {}) if isinstance(data, dict) else {}
            premium = []
            # hosts is a dict keyed by host name; each host has a 'domains' array
            iterable = hosts_obj.values() if isinstance(hosts_obj, dict) else hosts_obj
            for h_obj in iterable:
                if not isinstance(h_obj, dict):
                    continue
                if h_obj.get('status') is False:
                    continue
                for dom in h_obj.get('domains', []) or []:
                    premium.append((dom, dom.split('.')[0]))
            hosters['premium']['all_debrid'] = premium
        except Exception:
            import traceback
            traceback.print_exc()
            hosters['premium']['all_debrid'] = []

    # ---------------------------------------------------------------- link unlock

    def resolve_hoster(self, url):
        url = self.tools.quote(url)
        resolve = self.get_url('link/unlock?link={}'.format(url), token_req=True)
        if not resolve or not isinstance(resolve, dict):
            return None
        if resolve.get('status') == 'success':
            try:
                return resolve['data']['link']
            except Exception:
                return None
        try:
            err = resolve.get('error', {}).get('message', 'Unknown AllDebrid error')
            log.warning('AllDebrid unlock error: %s' % err)
        except Exception:
            pass
        return None

    # ---------------------------------------------------------------- helpers used by movie/tv resolve

    def _wait_until_ready(self, magnet_id, timeout=30):
        """Poll magnet/status until statusCode==4 (Ready) or an error/timeout.
        statusCode reference (per AllDebrid docs):
          0 In Queue, 1 Downloading, 2 Compressing/Moving, 3 Uploading, 4 Ready, 5+ errors.

        We use a *short* default timeout (30s) because we only call this when a magnet was
        already reported as cached at upload time; otherwise we bail out instead of stalling
        the UI on a real download (which is what previously caused the long countdown hangs).
        """
        deadline = time.time() + timeout
        last_code = None
        poll_interval = 2
        while time.time() < deadline:
            resp = self.magnet_status(magnet_id)
            try:
                m = resp['data']['magnets']
                if isinstance(m, list):
                    if not m:
                        return False
                    m = m[0]
                code = m.get('statusCode')
                last_code = code
                if code == 4:
                    return True
                if code == 3:
                    # Uploading - links are usually already available
                    return True
                if code is not None and code >= 5:
                    log.warning('AllDebrid magnet error statusCode=%s' % code)
                    return False
            except Exception:
                pass
            time.sleep(poll_interval)
        log.warning('AllDebrid magnet not Ready (last statusCode=%s)' % last_code)
        return False

    def _extract_links(self, files_resp):
        """Pull the flat [{link, filename}, ...] list out of a /magnet/files response.
        Walks nested folders so episode files inside subfolders are still discovered.
        """
        out = []

        def _walk(node):
            if isinstance(node, list):
                for it in node:
                    _walk(it)
                return
            if not isinstance(node, dict):
                return
            # Leaf: a single file entry has both `link` and `filename` (or just `n`).
            link = node.get('link') or node.get('l')
            name = node.get('filename') or node.get('n')
            if link and name:
                out.append({'link': link, 'filename': name})
            # Recurse into nested file trees: AD uses keys like `files`, `e` (entries).
            for key in ('files', 'e', 'links'):
                child = node.get(key)
                if child is not None:
                    _walk(child)

        try:
            magnets_arr = files_resp['data']['magnets']
            if isinstance(magnets_arr, list):
                if not magnets_arr:
                    return out
                obj = magnets_arr[0]
            elif isinstance(magnets_arr, dict):
                obj = magnets_arr
            else:
                return out
            # Newer responses use `files` (tree); older ones use a flat `links` list.
            if obj.get('files') is not None:
                _walk(obj.get('files'))
            if obj.get('links') is not None:
                _walk(obj.get('links'))
        except Exception:
            pass
        return out

    # ---------------------------------------------------------------- public resolvers

    def movie_magnet_to_stream(self, magnet, season, episode, tv_movie):
        selectedFile = None

        upload = self.upload_magnet(magnet)
        if not upload or upload.get('status') != 'success':
            try:
                err_msg = upload['error']['message']
            except Exception:
                err_msg = 'AllDebrid upload failed'
            log.warning('AllDebrid upload failed: %s' % err_msg)
            return None

        try:
            magnet_id = upload['data']['magnets'][0]['id']
            already_ready = bool(upload['data']['magnets'][0].get('ready'))
        except Exception:
            return None

        # Only wait briefly if AD already reported the magnet as cached; otherwise bail
        # to avoid the long "countdown" hang on non-cached torrents.
        if not already_ready:
            if not self._wait_until_ready(magnet_id, timeout=15):
                files_resp_probe = self.magnet_files(magnet_id)
                if not self._extract_links(files_resp_probe):
                    try:
                        self.delete_magnet(magnet_id)
                    except Exception:
                        pass
                    return None

        files_resp = self.magnet_files(magnet_id)
        folder_details = self._extract_links(files_resp)

        video_exts = ('.mkv', '.avi', '.mp4', '.m4v', '.mov', '.wmv', '.flv', '.ts', '.webm')
        for items in folder_details:
            test_name = items['filename'].lower()
            if not test_name.endswith(video_exts):
                continue

            if tv_movie == 'movie':
                selectedFile = items['link']
                break

            try:
                s_int = int(season)
                e_int = int(episode)
            except Exception:
                s_int = season
                e_int = episode
            s_pad = str(season).zfill(2)
            e_pad = str(episode).zfill(2)

            ep_patterns = (
                's%se%s.' % (s_pad, e_pad),
                's%se%s ' % (s_pad, e_pad),
                's%se%s-' % (s_pad, e_pad),
                's%se%s_' % (s_pad, e_pad),
                '%dx%s' % (int(s_int) if isinstance(s_int, int) else int(season), e_pad),
                'episode %d' % (int(e_int) if isinstance(e_int, int) else int(episode)),
                'ep %s' % e_pad,
                'ep%s' % e_pad,
                'e%s' % e_pad,
            )
            if any(p in test_name for p in ep_patterns):
                selectedFile = items['link']
                break

        try:
            self.delete_magnet(magnet_id)
        except Exception:
            pass

        if not selectedFile:
            return None
        return self.resolve_hoster(selectedFile)

    def resolve_magnet(self, magnet, args, torrent, pack_select=False):
        from resources.modules import source_utils
        if 'showInfo' not in args:
            return self.movie_magnet_to_stream(magnet, args, '', 'movie')

        upload = self.upload_magnet(magnet)
        if not upload or upload.get('status') != 'success':
            return None
        try:
            magnet_id = upload['data']['magnets'][0]['id']
            already_ready = bool(upload['data']['magnets'][0].get('ready'))
        except Exception:
            return None

        episodeStrings, seasonStrings = source_utils.torrentCacheStrings(args)

        try:
            if not already_ready:
                if not self._wait_until_ready(magnet_id, timeout=15):
                    files_resp_probe = self.magnet_files(magnet_id)
                    if not self._extract_links(files_resp_probe):
                        self.delete_magnet(magnet_id)
                        return None

            files_resp = self.magnet_files(magnet_id)
            folder_details = self._extract_links(files_resp)

            if 'extra' not in args['info']['title'] and 'extra' not in args['showInfo']['info']['tvshowtitle'] \
                    and int(args['info']['season']) != 0:
                folder_details = [i for i in folder_details if
                                  'extra' not in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower())]

            if 'special' not in args['info']['title'] and 'special' not in args['showInfo']['info']['tvshowtitle'] \
                    and int(args['info']['season']) != 0:
                folder_details = [i for i in folder_details if
                                  'special' not in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower())]

            streamLink = self.check_episode_string(folder_details, episodeStrings)
            self.delete_magnet(magnet_id)

            if streamLink is None:
                return None
            return self.resolve_hoster(streamLink)
        except Exception:
            import traceback
            traceback.print_exc()
            try:
                self.delete_magnet(magnet_id)
            except Exception:
                pass
            return None

    def check_episode_string(self, folder_details, episodeStrings):
        from resources.modules import source_utils
        for i in folder_details:
            for epstring in episodeStrings:
                if epstring in source_utils.cleanTitle(i['filename'].replace('&', ' ').lower()):
                    if any(i['filename'].lower().endswith(ext) for ext in source_utils.COMMON_VIDEO_EXTENSIONS):
                        return i['link']
        return None
