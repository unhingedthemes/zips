# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from cocoscrapersmod.modules.control import addonPath, addonVersion, joinPath
from cocoscrapersmod.windows.textviewer import TextViewerXML


def get():
	cocoscrapersmod_path = addonPath()
	cocoscrapersmod_version = addonVersion()
	changelogfile = joinPath(cocoscrapersmod_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]cocoscrapersmod -  v%s - ChangeLog[/B]' % cocoscrapersmod_version
	windows = TextViewerXML('textviewer.xml', cocoscrapersmod_path, heading=heading, text=text)
	windows.run()
	del windows