# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from absolutionscrapers.modules.control import addonPath, addonVersion, joinPath
from absolutionscrapers.windows.textviewer import TextViewerXML


def get():
	absolutionscrapers_path = addonPath()
	absolutionscrapers_version = addonVersion()
	changelogfile = joinPath(absolutionscrapers_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]absolutionscrapers -  v%s - ChangeLog[/B]' % absolutionscrapers_version
	windows = TextViewerXML('textviewer.xml', absolutionscrapers_path, heading=heading, text=text)
	windows.run()
	del windows