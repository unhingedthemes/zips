# -*- coding: utf-8 -*-

import re
import requests
from urllib.parse import urlencode, parse_qs, urljoin

from absolutionscrapers import custom_base_link
from absolutionscrapers.modules import cleantitle
from absolutionscrapers.modules import client
from absolutionscrapers.modules import debrid
from absolutionscrapers.modules import source_utils
from absolutionscrapers.modules import log_utils

custom_base = custom_base_link(__name__)

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['mediafusion.elfhosted.com']
        self.base_link = custom_base or 'https://mediafusion.elfhosted.com'
        self.movie_search_link = '/stream/movie/{0}.json'
        self.tv_search_link = '/stream/series/{0}:{1}:{2}.json'
        self.pack_capable = True
        self.min_seeders = 0
        self.aliases = []

    def _headers(self):
        headers = {
            'encoded_user_data': 'eyJlbmFibGVfY2F0YWxvZ3MiOiBmYWxzZSwgIm1heF9zdHJlYW1zX3Blcl9yZXNvbHV0aW9uIjogOTksICJ0b3JyZW50X3NvcnRpbmdfcHJpb3JpdHkiOiBbXSwgImNlcnRpZmljYXRpb25fZmlsdGVyIjogWyJEaXNhYmxlIl0sICJudWRpdHlfZmlsdGVyIjogWyJEaXNhYmxlIl19'
        }
        return headers

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            self.aliases.extend(aliases)
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.log('MediaFusion - Exception', 1)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            self.aliases.extend(aliases)
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.log('MediaFusion - Exception', 1)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.log('MediaFusion - Exception', 1)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not debrid.status():
                return sources
            if not url:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
            episode_title = data['title'] if 'tvshowtitle' in data else None
            year = data['year']
            imdb = data['imdb']
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year

            search_url = urljoin(self.base_link, self.tv_search_link.format(imdb, data['season'], data['episode'])) if 'tvshowtitle' in data else urljoin(self.base_link, self.movie_search_link.format(imdb))

            results = client.request(search_url, headers=self._headers(), timeout=7)
            files = results.get('streams', []) if results else []

            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()
            info_regex = re.compile(r'💾.*')

            for file in files:
                try:
                    hash = file.get('infoHash') or file['url'].split('/')[file['url'].split('/').index('stream') + 1]
                    file_title = file['behaviorHints']['filename'].split('\n')
                    file_info = [x for x in file['description'].split('\n') if info_regex.match(x)][0]
                    name = source_utils.clean_name(file_title[0])

                    if not source_utils.is_match(name.replace('.(Archie.Bunker', ''), title, hdlr, self.aliases):
                        continue

                    name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                    if source_utils.remove_lang(name_info, check_foreign_audio) or (undesirables and source_utils.remove_undesirables(name_info, undesirables)):
                        continue

                    magnet_url = f'magnet:?xt=urn:btih:{hash}&dn={name}'
                    try:
                        seeders = int(re.search(r'(\d+)', file_info).group(1))
                        if self.min_seeders > seeders:
                            continue
                    except:
                        seeders = 0

                    quality, info = source_utils.get_release_quality(name_info, magnet_url)
                    try:
                        size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
                        dsize, isize = source_utils._size(size)
                        info.insert(0, isize)
                    except:
                        dsize = 0

                    info = ' | '.join(info)
                    sources.append({
                        'source': 'torrent',
                        'quality': quality,
                        'language': 'en',
                        'url': magnet_url,
                        'info': info,
                        'direct': False,
                        'debridonly': True,
                        'size': dsize,
                        'name': name
                    })
                except:
                    log_utils.log('MediaFusion - Exception', 1)
                    continue

            return sources
        except:
            log_utils.log('MediaFusion - Exception', 1)
            return sources

    def sources_packs(self, url, hostDict, hostprDict, search_series=False, total_seasons=None):
        sources = []
        try:
            if not debrid.status() or not url:
                return sources

            # Note: Pack support assumes setting check similar to original, but absolutionscrapers may not have direct equivalent
            # Assuming a setting check would be handled externally or via custom logic
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
            year = data['year']
            imdb = data['imdb']
            season = data['season']

            search_url = urljoin(self.base_link, self.tv_search_link.format(imdb, season, data['episode']))
            results = client.request(search_url, headers=self._headers(), timeout=7)
            files = results.get('streams', []) if results else []

            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()
            info_regex = re.compile(r'💾.*')

            for file in files:
                try:
                    hash = file.get('infoHash') or file['url'].split('/')[file['url'].split('/').index('stream') + 1]
                    file_title = file['description'].split('\n')
                    file_info = [x for x in file_title if info_regex.match(x)][0]
                    name = source_utils.clean_name(file_title[0])

                    episode_start, episode_end = 0, 0
                    if not search_series:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(title, self.aliases, year, season, name.replace('.(Archie.Bunker', ''))
                        if not valid:
                            continue
                        package = 'season'
                    else:
                        valid, last_season = source_utils.filter_show_pack(title, self.aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
                        if not valid:
                            continue
                        package = 'show'

                    name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
                    if source_utils.remove_lang(name_info, check_foreign_audio) or (undesirables and source_utils.remove_undesirables(name_info, undesirables)):
                        continue

                    magnet_url = f'magnet:?xt=urn:btih:{hash}&dn={name}'
                    try:
                        seeders = int(re.search(r'(\d+)', file_info).group(1))
                        if self.min_seeders > seeders:
                            continue
                    except:
                        seeders = 0

                    quality, info = source_utils.get_release_quality(name_info, magnet_url)
                    try:
                        size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
                        dsize, isize = source_utils._size(size)
                        info.insert(0, isize)
                    except:
                        dsize = 0

                    info = ' | '.join(info)
                    item = {
                        'source': 'torrent',
                        'quality': quality,
                        'language': 'en',
                        'url': magnet_url,
                        'info': info,
                        'direct': False,
                        'debridonly': True,
                        'size': dsize,
                        'name': name,
                        'package': package
                    }
                    if search_series:
                        item.update({'last_season': last_season})
                    elif episode_start:
                        item.update({'episode_start': episode_start, 'episode_end': episode_end})

                    sources.append(item)
                except:
                    log_utils.log('MediaFusion - Exception', 1)
                    continue

            return sources
        except:
            log_utils.log('MediaFusion - Exception', 1)
            return sources

    def resolve(self, url):
        return url