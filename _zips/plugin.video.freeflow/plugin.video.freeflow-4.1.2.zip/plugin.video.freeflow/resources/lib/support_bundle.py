# -*- coding: utf-8 -*-
"""Build a Free Flow support bundle (.zip).

Contents
--------
  - debug.log            : addon debug log (and rotated debug.log.1 if any)
  - kodi-freeflow.log    : lines extracted from Kodi's main log that were
                           emitted by this addon (filtered for privacy)
  - system_info.txt      : Kodi version, Python version, OS, addon version,
                           addon settings (with the API key redacted)
  - resolver_probe.txt   : live ddownload API connectivity check + key status

The zip is written under the addon profile so the user can hand it over
verbatim. Path is returned to the caller.
"""
import json
import os
import platform
import re
import sys
import time
import zipfile

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
except Exception:
    xbmc = xbmcvfs = xbmcaddon = None

try:
    import requests
except Exception:
    requests = None


ADDON_ID = 'plugin.video.freeflow'
_API_KEY_KEYS = ('ddl_api_key',)


def _profile_dir():
    if xbmcvfs is None:
        return '/tmp'
    return xbmcvfs.translatePath(
        'special://profile/addon_data/%s/' % ADDON_ID)


def _kodi_log_path():
    """Return the path to Kodi's main log (kodi.log)."""
    if xbmcvfs is None:
        return None
    candidates = [
        xbmcvfs.translatePath('special://logpath/kodi.log'),
        xbmcvfs.translatePath('special://logpath/kodi.old.log'),
    ]
    for p in candidates:
        if p and os.path.exists(p):
            return p
    return None


def _redact(text):
    """Strip ddownload API keys and other obvious secrets from any text."""
    if not text:
        return text
    # Bundled default key + any key=<token> in URLs / settings dumps
    text = re.sub(r'(?i)(key=)[A-Za-z0-9]{8,}', r'\1<redacted>', text)
    text = re.sub(r'47853810ypry7vy7fmy9hi', '<redacted-default-key>',
                  text)
    return text


def _extract_freeflow_lines(kodi_log_path, max_bytes=2 * 1024 * 1024):
    """Pull only the addon-tagged lines out of kodi.log.

    Reads at most the last `max_bytes` of the file so a 200 MB kodi.log
    doesn't kill us.
    """
    if not kodi_log_path or not os.path.exists(kodi_log_path):
        return '(kodi.log not found)\n'
    try:
        size = os.path.getsize(kodi_log_path)
        with open(kodi_log_path, 'rb') as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
                # discard partial first line
                f.readline()
            blob = f.read().decode('utf-8', errors='replace')
    except Exception as e:
        return '(failed to read kodi.log: %s)\n' % e

    # Match either explicit addon tag or service tag
    needle_re = re.compile(
        r'\[%s(?:\.service)?\]|plugin\.video\.freeflow' % re.escape(ADDON_ID))
    out_lines = []
    for line in blob.splitlines():
        if needle_re.search(line):
            out_lines.append(line)
    if not out_lines:
        return '(no Free Flow lines found in last %d bytes of kodi.log)\n' \
               % max_bytes
    header = ('# Extracted Free Flow lines from %s (last %d bytes scanned)\n'
              '# Total matched lines: %d\n\n'
              % (kodi_log_path, min(size, max_bytes), len(out_lines)))
    return header + '\n'.join(out_lines) + '\n'


def _addon():
    if xbmcaddon is None:
        return None
    try:
        return xbmcaddon.Addon(ADDON_ID)
    except Exception:
        return None


def _settings_dump(addon):
    """Best-effort dump of all addon settings, with API keys redacted."""
    out = {}
    if addon is None:
        return out
    # Settings IDs we care about (must match settings.xml)
    ids = [
        'debug_logging', 'show_splash', 'download_folder', 'ddl_api_key',
    ]
    for sid in ids:
        try:
            v = addon.getSetting(sid)
        except Exception:
            v = '(error)'
        if sid in _API_KEY_KEYS and v:
            v = '<set, %d chars>' % len(v)
        out[sid] = v
    return out


def _system_info_text(addon):
    info = {}
    info['timestamp_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ',
                                          time.gmtime())
    try:
        info['addon_version'] = addon.getAddonInfo('version') if addon else '?'
        info['addon_id'] = addon.getAddonInfo('id') if addon else ADDON_ID
    except Exception:
        info['addon_version'] = '?'
    info['python'] = sys.version.replace('\n', ' ')
    info['platform'] = platform.platform()
    info['machine'] = platform.machine()
    try:
        info['kodi_build'] = (xbmc.getInfoLabel('System.BuildVersion')
                              if xbmc else '?')
    except Exception:
        info['kodi_build'] = '?'
    try:
        info['kodi_friendly_name'] = (xbmc.getInfoLabel('System.FriendlyName')
                                      if xbmc else '?')
    except Exception:
        info['kodi_friendly_name'] = '?'
    try:
        info['os_version'] = (xbmc.getInfoLabel('System.OSVersionInfo')
                              if xbmc else '?')
    except Exception:
        info['os_version'] = '?'
    try:
        info['screen'] = (xbmc.getInfoLabel('System.ScreenResolution')
                          if xbmc else '?')
    except Exception:
        info['screen'] = '?'
    info['settings'] = _settings_dump(addon)

    # Installed deps that matter to playback
    deps = {}
    for dep in ('script.module.requests', 'script.module.resolveurl'):
        try:
            deps[dep] = xbmcaddon.Addon(dep).getAddonInfo('version')
        except Exception as e:
            deps[dep] = 'NOT INSTALLED (%s)' % e
    info['dependencies'] = deps

    return json.dumps(info, indent=2, ensure_ascii=False)


def _resolver_probe(addon):
    """Live, anonymous probe of the ddownload premium API so we can tell
    upstream-vs-our-end at a glance. Uses the user's configured key (or the
    bundled default) but redacts it from output."""
    lines = ['# Free Flow resolver probe', '']
    if requests is None:
        lines.append('requests module not available - cannot probe')
        return '\n'.join(lines) + '\n'
    key = ''
    try:
        key = (addon.getSetting('ddl_api_key') or '').strip() if addon else ''
    except Exception:
        pass
    if not key:
        key = '47853810ypry7vy7fmy9hi'  # bundled default
        lines.append('Using bundled default ddownload key.')
    else:
        lines.append('Using user-configured ddownload key (length=%d).'
                     % len(key))
    test_code = 'ti4wzjmvpxn1'  # T.J. Hooker S01e01 - known good code
    url = ('https://api-v2.ddownload.com/api/file/direct_link'
           '?key=%s&file_code=%s' % (key, test_code))
    lines.append('GET %s' % _redact(url))
    try:
        t0 = time.time()
        r = requests.get(url, timeout=15,
                         headers={'User-Agent': 'FreeFlowSupportProbe/1.0'})
        dt = (time.time() - t0) * 1000.0
        lines.append('-> HTTP %s in %.0fms' % (r.status_code, dt))
        try:
            data = r.json()
        except Exception:
            data = None
        if isinstance(data, dict):
            data_copy = dict(data)
            # don't leak any reflected key
            res = data_copy.get('result')
            if isinstance(res, dict) and res.get('url'):
                res['url'] = '<redacted-direct-url>'
            elif isinstance(res, list):
                for item in res:
                    if isinstance(item, dict) and item.get('url'):
                        item['url'] = '<redacted-direct-url>'
            lines.append('Body: ' + json.dumps(data_copy, ensure_ascii=False))
        else:
            lines.append('Body (non-JSON, %d bytes): %s'
                         % (len(r.text or ''),
                            _redact((r.text or '')[:400])))
    except Exception as e:
        lines.append('-> EXCEPTION: %s' % e)
    return '\n'.join(lines) + '\n'


def build_support_zip(out_dir=None):
    """Build the support bundle and return the absolute zip path."""
    if out_dir is None:
        out_dir = _profile_dir()
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception:
        pass
    ts = time.strftime('%Y%m%d-%H%M%S')
    zip_path = os.path.join(out_dir, 'freeflow-support-%s.zip' % ts)

    addon = _addon()

    sys_text = _redact(_system_info_text(addon))
    probe_text = _redact(_resolver_probe(addon))
    debug_log = os.path.join(_profile_dir(), 'debug.log')
    debug_log_old = debug_log + '.1'
    kodi_slice = _redact(_extract_freeflow_lines(_kodi_log_path()))

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('system_info.txt', sys_text)
        z.writestr('resolver_probe.txt', probe_text)
        z.writestr('kodi-freeflow.log', kodi_slice)
        if os.path.exists(debug_log):
            try:
                with open(debug_log, 'r', encoding='utf-8',
                          errors='replace') as f:
                    z.writestr('debug.log', _redact(f.read()))
            except Exception as e:
                z.writestr('debug.log', '(failed to read debug.log: %s)' % e)
        else:
            z.writestr('debug.log', '(no debug.log yet)')
        if os.path.exists(debug_log_old):
            try:
                with open(debug_log_old, 'r', encoding='utf-8',
                          errors='replace') as f:
                    z.writestr('debug.log.1', _redact(f.read()))
            except Exception:
                pass
        z.writestr('README.txt',
                   'Free Flow Support Bundle\n'
                   '------------------------\n'
                   'Generated: %s\n\n'
                   'system_info.txt    - Kodi/Python/OS/addon versions and '
                   'sanitised settings.\n'
                   'resolver_probe.txt - Live ddownload API connectivity '
                   'test (key redacted).\n'
                   'debug.log          - Addon debug log.\n'
                   'kodi-freeflow.log  - Lines from Kodi main log emitted by '
                   'this addon only.\n'
                   '\nAll API keys and resolved direct URLs have been '
                   'redacted before zipping.\n' % ts)

    return zip_path
