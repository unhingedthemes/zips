"""
	Venom Add-on
"""

from resources.lib.modules.control import addonPath, addonId, getgenocideVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	genocide_path = addonPath(addonId())
	genocide_version = getgenocideVersion()
	helpFile = joinPath(genocide_path, 'resources', 'help', file + '.txt')
	f = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]genocide -  v%s - %s[/B]' % (genocide_version, file)
	windows = TextViewerXML('textviewer.xml', genocide_path, heading=heading, text=text)
	windows.run()
	del windows
