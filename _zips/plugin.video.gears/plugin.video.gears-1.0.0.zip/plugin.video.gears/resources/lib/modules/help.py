# -*- coding: utf-8 -*-
"""
	gears Add-on
"""

from resources.lib.modules.control import addonPath, addonId, getgearsVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	gears_path = addonPath(addonId())
	gears_version = getgearsVersion()
	helpFile = joinPath(gears_path, 'resources', 'help', file + '.txt')
	f = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]gears -  v%s - %s[/B]' % (gears_version, file)
	windows = TextViewerXML('textviewer.xml', gears_path, heading=heading, text=text)
	windows.run()
	del windows
