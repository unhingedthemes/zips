# -*- coding: utf-8 -*-
import sys
from xbmc import executebuiltin, sleep

mode = sys.argv[1]
if   mode == 'refresh_widgets':
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'luffy_watched_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_watched_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'luffy_unwatched_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_unwatched_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'luffy_clearprog_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_clearprog_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'luffy_browse_params':
	executebuiltin('ActivateWindow(Videos,%s)' % sys.listitem.getProperty('luffy_browse_params'))
elif mode == 'luffy_browse_seas_params':
	executebuiltin('ActivateWindow(Videos,%s)' % sys.listitem.getProperty('luffy_browse_seas_params'))
elif mode == 'luffy_trakt_manager_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_trakt_manager_params'))
elif mode == 'luffy_fav_manager_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_fav_manager_params'))
elif mode == 'luffy_random_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_random_params'))
elif mode == 'luffy_options_menu_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('luffy_options_menu_params'))
elif mode == 'luffy_extras_menu_params':
	params = sys.listitem.getProperty('luffy_extras_menu_params')
	params += '&is_widget=false&is_home=true'
	executebuiltin('RunPlugin(%s)' % params)

