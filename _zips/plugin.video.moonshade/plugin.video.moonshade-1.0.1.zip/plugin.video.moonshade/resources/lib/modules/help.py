"""
	Venom Add-on
"""

from resources.lib.modules.control import addonPath, addonId, getmoonshadeVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	moonshade_path = addonPath(addonId())
	moonshade_version = getmoonshadeVersion()
	helpFile = joinPath(moonshade_path, 'resources', 'help', file + '.txt')
	f = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]moonshade -  v%s - %s[/B]' % (moonshade_version, file)
	windows = TextViewerXML('textviewer.xml', moonshade_path, heading=heading, text=text)
	windows.run()
	del windows
