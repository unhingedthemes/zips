import os
import shutil
import time
import sqlite3
import xbmc
import xbmcgui
import xbmcvfs

from .addonvar import addon_name, addon_icon


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)  # Kodi 19+
    except Exception:
        return xbmc.translatePath(path)     # legacy fallback


def _log(msg):
    try:
        xbmc.log('%s: %s' % (addon_name, msg), xbmc.LOGINFO)
    except Exception:
        pass


user_path = _translate('special://home/userdata')
cache_path = _translate('special://home/cache')
temp_path = _translate('special://temp')
database_path = _translate('special://database')


def _purge_tree(path, skip_files=None, skip_dirs=None):
    skip_files = set(skip_files or [])
    skip_dirs = set(skip_dirs or [])

    if not path or not os.path.exists(path):
        return

    for root, dirs, files in os.walk(path):
        for f in files:
            if f in skip_files:
                continue
            fp = os.path.join(root, f)
            try:
                os.unlink(fp)
            except Exception as e:
                _log('Failed deleting file %s: %s' % (fp, e))

        for d in dirs:
            if d in skip_dirs:
                continue
            dp = os.path.join(root, d)
            try:
                shutil.rmtree(dp, ignore_errors=True)
            except Exception as e:
                _log('Failed deleting dir %s: %s' % (dp, e))


def clear_cache(show_notification=True):
    keep = set([
        'xbmc.log', 'xbmc.old.log',
        'kodi.log', 'kodi.old.log',
        'archive_cache', 'commoncache.db', 'commoncache.socket', 'temp'
    ])

    _purge_tree(cache_path, skip_files=keep, skip_dirs=set(['archive_cache', 'temp']))
    _purge_tree(temp_path, skip_files=keep, skip_dirs=set(['archive_cache', 'temp']))

    if show_notification:
        xbmcgui.Dialog().notification(addon_name, 'Cache cleared', addon_icon, 3000)


def clear_packages(show_notification=True):
    packages_path = _translate('special://home/addons/packages')
    _purge_tree(packages_path)

    if show_notification:
        xbmcgui.Dialog().notification(addon_name, 'Packages cleared', addon_icon, 3000)


def clear_thumbnails(show_notification=True):
    confirm = xbmcgui.Dialog().yesno(
        addon_name,
        'This will delete all thumbnails and texture database.\nKodi will close when done.\n\nContinue?',
        yeslabel='OK',
        nolabel='Cancel'
    )
    if not confirm:
        return False

    thumbs_userdata = os.path.join(user_path, 'Thumbnails')
    thumbs_special = _translate('special://thumbnails')

    try:
        _purge_tree(thumbs_special)
    except Exception as e:
        _log('Failed wiping special thumbnails path: %s' % e)

    try:
        _purge_tree(thumbs_userdata)
    except Exception as e:
        _log('Failed wiping userdata thumbnails path: %s' % e)

    try:
        tex_db = os.path.join(database_path, 'Textures13.db')
        if os.path.exists(tex_db):
            os.unlink(tex_db)
    except Exception as e:
        _log('Failed deleting Textures13.db: %s' % e)

    xbmcgui.Dialog().ok(addon_name, 'Thumbnail cleanup complete.\nKodi will now close.')
    xbmc.executebuiltin('Quit')
    return True


def _find_latest_textures_db():
    try:
        files = os.listdir(database_path)
    except Exception:
        return None

    latest_num = -1
    latest_file = None
    for f in files:
        lf = f.lower()
        if lf.startswith('textures') and lf.endswith('.db'):
            num = ''.join(ch for ch in f if ch.isdigit())
            try:
                v = int(num) if num else -1
            except Exception:
                v = -1
            if v > latest_num:
                latest_num = v
                latest_file = f

    if latest_file:
        return os.path.join(database_path, latest_file)
    return None


def clear_thumbnails_unused_old(show_notification=True, older_than_days=30):
    tex_db = _find_latest_textures_db()
    if not tex_db or not os.path.exists(tex_db):
        if show_notification:
            xbmcgui.Dialog().notification(addon_name, 'No texture database found', addon_icon, 3000)
        return False

    thumb_roots = []
    thumbs_userdata = os.path.join(user_path, 'Thumbnails')
    thumbs_special = _translate('special://thumbnails')

    if thumbs_special and os.path.exists(thumbs_special):
        thumb_roots.append(thumbs_special)
    if thumbs_userdata and os.path.exists(thumbs_userdata) and thumbs_userdata not in thumb_roots:
        thumb_roots.append(thumbs_userdata)

    if not thumb_roots:
        if show_notification:
            xbmcgui.Dialog().notification(addon_name, 'No thumbnails folder found', addon_icon, 3000)
        return False

    valid_rel = set()
    conn = None
    try:
        conn = sqlite3.connect(tex_db, timeout=2)
        cur = conn.cursor()
        cur.execute('SELECT cachedurl FROM texture')
        rows = cur.fetchall()
        for r in rows:
            if r and r[0]:
                valid_rel.add(str(r[0]).replace('\\', '/').lstrip('/'))
    except Exception as e:
        _log('Failed reading texture DB %s: %s' % (tex_db, e))
    finally:
        if conn:
            conn.close()

    now = int(time.time())
    age_sec = max(1, int(older_than_days)) * 86400

    deleted = 0
    skipped = 0
    failed = 0

    for root in thumb_roots:
        for base, dirs, files in os.walk(root):
            for f in files:
                fp = os.path.join(base, f)
                rel = os.path.relpath(fp, root).replace('\\', '/')

                is_unused = rel not in valid_rel if valid_rel else False
                is_old = False
                try:
                    mtime = int(os.path.getmtime(fp))
                    is_old = (now - mtime) >= age_sec
                except Exception:
                    pass

                if not is_unused and not is_old:
                    skipped += 1
                    continue

                try:
                    os.unlink(fp)
                    deleted += 1
                except Exception:
                    failed += 1

    _log('Selective thumbs cleanup done: deleted=%d skipped=%d failed=%d' % (deleted, skipped, failed))

    if show_notification:
        msg = '%d thumbnails cleaned (unused/old)' % deleted
        if failed:
            msg += ' | %d failed' % failed
        xbmcgui.Dialog().notification(addon_name, msg, addon_icon, 5000)

    return True


def optimize_databases_manual(show_notification=True, include_addon_dbs=True):
    db_files = []

    db_dir = _translate('special://database')
    if db_dir and os.path.exists(db_dir):
        try:
            for f in os.listdir(db_dir):
                lf = f.lower()
                if lf.endswith('.db') or lf.endswith('.sqlite'):
                    db_files.append(os.path.join(db_dir, f))
        except Exception as e:
            _log('Failed listing core database dir %s: %s' % (db_dir, e))

    if include_addon_dbs:
        addon_data_dir = _translate('special://profile/addon_data')
        if addon_data_dir and os.path.exists(addon_data_dir):
            try:
                for addon_id in os.listdir(addon_data_dir):
                    addon_path = os.path.join(addon_data_dir, addon_id)
                    if not os.path.isdir(addon_path):
                        continue

                    try:
                        for f in os.listdir(addon_path):
                            fp = os.path.join(addon_path, f)
                            lf = f.lower()
                            if os.path.isfile(fp) and (lf.endswith('.db') or lf.endswith('.sqlite')):
                                db_files.append(fp)
                    except Exception:
                        pass

                    try:
                        for sub in os.listdir(addon_path):
                            sub_path = os.path.join(addon_path, sub)
                            if not os.path.isdir(sub_path):
                                continue
                            try:
                                for f in os.listdir(sub_path):
                                    fp = os.path.join(sub_path, f)
                                    lf = f.lower()
                                    if os.path.isfile(fp) and (lf.endswith('.db') or lf.endswith('.sqlite')):
                                        db_files.append(fp)
                            except Exception:
                                pass
                    except Exception:
                        pass
            except Exception as e:
                _log('Failed listing addon_data dir %s: %s' % (addon_data_dir, e))

    db_files = list(dict.fromkeys(db_files))

    if not db_files:
        if show_notification:
            xbmcgui.Dialog().notification(addon_name, 'No databases found to optimize', addon_icon, 3000)
        return

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, 'Optimizing databases...')

    optimized = []
    locked = []
    failed = []

    total = len(db_files)

    try:
        for idx, db_path in enumerate(db_files, start=1):
            if progress.iscanceled():
                _log('Database optimize canceled by user.')
                break

            db_name = os.path.basename(db_path)
            pct = int((float(idx - 1) / float(total)) * 100)
            progress.update(pct, 'Optimizing: %s (%d/%d)' % (db_name, idx, total))

            conn = None
            try:
                conn = sqlite3.connect(db_path, timeout=1)
                conn.execute('PRAGMA quick_check;')
                conn.execute('VACUUM;')
                conn.close()
                conn = None
                optimized.append(db_path)
            except sqlite3.OperationalError as e:
                msg = str(e).lower()
                if 'locked' in msg or 'busy' in msg:
                    locked.append('%s (%s)' % (db_path, e))
                else:
                    failed.append('%s (%s)' % (db_path, e))
                if conn:
                    conn.close()
            except Exception as e:
                failed.append('%s (%s)' % (db_path, e))
                if conn:
                    conn.close()

        progress.update(100, 'Database optimization complete')
        progress.close()

        _log('DB optimize done. optimized=%d locked=%d failed=%d total=%d include_addon_dbs=%s' %
             (len(optimized), len(locked), len(failed), total, include_addon_dbs))

        if show_notification:
            msg = '%d databases optimized' % len(optimized)
            if locked:
                msg += ' | %d locked' % len(locked)
            if failed:
                msg += ' | %d failed' % len(failed)
            xbmcgui.Dialog().notification(addon_name, msg, addon_icon, 5000)

        if locked or failed:
            details = []
            if locked:
                details.append('Locked:\n- ' + '\n- '.join(locked))
            if failed:
                details.append('Failed:\n- ' + '\n- '.join(failed))
            xbmcgui.Dialog().textviewer('%s - DB Optimize Details' % addon_name, '\n\n'.join(details))

    except Exception as e:
        try:
            progress.close()
        except Exception:
            pass
        _log('optimize_databases_manual failed: %s' % e)
        if show_notification:
            xbmcgui.Dialog().notification(addon_name, 'Database optimize failed', addon_icon, 3000)


def run_scheduled_clean_if_due(force_run=False):
    try:
        import xbmcaddon
        a = xbmcaddon.Addon()

        def _b(k, d=False):
            v = a.getSetting(k)
            return (v.lower() == 'true') if v else d

        def _i(k, d=0):
            try:
                return int(a.getSetting(k))
            except Exception:
                return d

        enabled = _b('autoclean_enable', False)

        prev = a.getSetting('autoclean_prev_enable')
        curr = 'true' if enabled else 'false'

        if prev == '':
            a.setSetting('autoclean_prev_enable', curr)
        elif prev != curr:
            a.setSetting('autoclean_lastrun', '0')
            a.setSetting('autoclean_prev_enable', curr)
            _log('AutoClean enable toggled (%s -> %s); reset lastrun to 0.' % (prev, curr))

        if not enabled:
            if force_run:
                xbmcgui.Dialog().notification(addon_name, 'AutoClean is disabled in settings.', addon_icon, 3000)
            return

        now = int(time.time())
        last_run = _i('autoclean_lastrun', 0)
        days = max(1, _i('autoclean_days', 7))

        first_run_due = (last_run <= 0)
        schedule_due = False if first_run_due else (now >= (last_run + (days * 86400)))

        if not force_run and not first_run_due and not schedule_due:
            return

        did_clean = False
        actions = []

        if _b('autoclean_packages', True):
            clear_packages(show_notification=False)
            did_clean = True
            actions.append('Packages')

        if _b('autoclean_cache', True):
            clear_cache(show_notification=False)
            did_clean = True
            actions.append('Cache')

        if _b('autoclean_thumbs_lite', False):
            clear_thumbnails_unused_old(show_notification=False, older_than_days=30)
            did_clean = True
            actions.append('Thumbnails')

        if _b('autoclean_dbopt', False):
            include_addon_dbs = _b('autoclean_dbopt_addons', False)
            optimize_databases_manual(show_notification=False, include_addon_dbs=include_addon_dbs)
            did_clean = True
            actions.append('DB Optimize')
            if include_addon_dbs:
                actions.append('Addon DBs')

        if not did_clean:
            _log('AutoClean run had no enabled actions; lastrun unchanged.')
            if force_run:
                xbmcgui.Dialog().notification(addon_name, 'No AutoClean actions are enabled.', addon_icon, 3000)
            return

        a.setSetting('autoclean_lastrun', str(now))

        action_text = ' + '.join(actions)
        if force_run:
            msg = f'AutoClean run now: {action_text}'
            _log('AutoClean manual run completed; lastrun=%s actions=%s' % (now, action_text))
        elif first_run_due:
            msg = f'AutoClean complete (first run): {action_text}'
            _log('AutoClean first run completed; lastrun=%s actions=%s' % (now, action_text))
        else:
            msg = f'AutoClean complete: {action_text}'
            _log('AutoClean scheduled run completed; lastrun=%s actions=%s' % (now, action_text))

        xbmcgui.Dialog().notification(addon_name, msg, addon_icon, 3500)

    except Exception as e:
        _log('run_scheduled_clean_if_due failed: %s' % e)