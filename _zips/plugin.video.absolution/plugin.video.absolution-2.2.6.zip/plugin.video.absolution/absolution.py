# -*- coding: utf-8 -*-

'''
    absolution Add-on
'''

from sys import argv
from resources.lib.modules import router
router.routing(argv[2])
