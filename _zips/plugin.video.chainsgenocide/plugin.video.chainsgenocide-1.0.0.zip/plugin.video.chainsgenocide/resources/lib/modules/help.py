# -*- coding: utf-8 -*-
"""
	Venom Add-on
"""

from resources.lib.modules.control import addonPath, addonId, getchainsgenocideVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	chainsgenocide_path = addonPath(addonId())
	chainsgenocide_version = getchainsgenocideVersion()
	helpFile = joinPath(chainsgenocide_path, 'resources', 'help', file + '.txt')
	f = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]chainsgenocide -  v%s - %s[/B]' % (chainsgenocide_version, file)
	windows = TextViewerXML('textviewer.xml', chainsgenocide_path, heading=heading, text=text)
	windows.run()
	del windows
